gdjs.Main_32Menu_32pcCode = {};
gdjs.Main_32Menu_32pcCode.GDEnterObjects1= [];
gdjs.Main_32Menu_32pcCode.GDEnterObjects2= [];
gdjs.Main_32Menu_32pcCode.GDfinObjects1= [];
gdjs.Main_32Menu_32pcCode.GDfinObjects2= [];
gdjs.Main_32Menu_32pcCode.GDRoBug2Objects1= [];
gdjs.Main_32Menu_32pcCode.GDRoBug2Objects2= [];
gdjs.Main_32Menu_32pcCode.GDPlayer2Objects1= [];
gdjs.Main_32Menu_32pcCode.GDPlayer2Objects2= [];
gdjs.Main_32Menu_32pcCode.GDPlayer2HitBoxObjects1= [];
gdjs.Main_32Menu_32pcCode.GDPlayer2HitBoxObjects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject2Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject2Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject3Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject3Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObjectObjects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObjectObjects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject4Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject4Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject5Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject5Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject6Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject6Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject7Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject7Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject8Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject8Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject9Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject9Objects2= [];
gdjs.Main_32Menu_32pcCode.GDStPRITZXObjects1= [];
gdjs.Main_32Menu_32pcCode.GDStPRITZXObjects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject10Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject10Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject11Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject11Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject12Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject12Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject13Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject13Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewObject14Objects1= [];
gdjs.Main_32Menu_32pcCode.GDNewObject14Objects2= [];
gdjs.Main_32Menu_32pcCode.GDNewTextObjects1= [];
gdjs.Main_32Menu_32pcCode.GDNewTextObjects2= [];

gdjs.Main_32Menu_32pcCode.conditionTrue_0 = {val:false};
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0 = {val:false};
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0 = {val:false};
gdjs.Main_32Menu_32pcCode.condition2IsTrue_0 = {val:false};


gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.Main_32Menu_32pcCode.GDNewObjectObjects1});
gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject4Objects1Objects = Hashtable.newFrom({"NewObject4": gdjs.Main_32Menu_32pcCode.GDNewObject4Objects1});
gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject6Objects1Objects = Hashtable.newFrom({"NewObject6": gdjs.Main_32Menu_32pcCode.GDNewObject6Objects1});
gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject7Objects1Objects = Hashtable.newFrom({"NewObject7": gdjs.Main_32Menu_32pcCode.GDNewObject7Objects1});
gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject10Objects1Objects = Hashtable.newFrom({"NewObject10": gdjs.Main_32Menu_32pcCode.GDNewObject10Objects1});
gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDStPRITZXObjects1Objects = Hashtable.newFrom({"StPRITZX": gdjs.Main_32Menu_32pcCode.GDStPRITZXObjects1});
gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject12Objects1Objects = Hashtable.newFrom({"NewObject12": gdjs.Main_32Menu_32pcCode.GDNewObject12Objects1});
gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject14Objects1Objects = Hashtable.newFrom({"NewObject14": gdjs.Main_32Menu_32pcCode.GDNewObject14Objects1});
gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject13Objects1Objects = Hashtable.newFrom({"NewObject13": gdjs.Main_32Menu_32pcCode.GDNewObject13Objects1});
gdjs.Main_32Menu_32pcCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.Main_32Menu_32pcCode.GDNewObjectObjects1);

gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObjectObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val ) {
{
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "w", false);
}}

}


{


gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject11"), gdjs.Main_32Menu_32pcCode.GDNewObject11Objects1);
{for(var i = 0, len = gdjs.Main_32Menu_32pcCode.GDNewObject11Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32pcCode.GDNewObject11Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject4"), gdjs.Main_32Menu_32pcCode.GDNewObject4Objects1);

gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject4Objects1Objects, runtimeScene, true, false);
}if ( gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val ) {
{
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}}

}


{


gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Controller_X_is_connected.func(runtimeScene, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject5"), gdjs.Main_32Menu_32pcCode.GDNewObject5Objects1);
{for(var i = 0, len = gdjs.Main_32Menu_32pcCode.GDNewObject5Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32pcCode.GDNewObject5Objects1[i].hide(false);
}
}}

}


{


gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject5"), gdjs.Main_32Menu_32pcCode.GDNewObject5Objects1);
{for(var i = 0, len = gdjs.Main_32Menu_32pcCode.GDNewObject5Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32pcCode.GDNewObject5Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject6"), gdjs.Main_32Menu_32pcCode.GDNewObject6Objects1);

gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject6Objects1Objects, runtimeScene, true, false);
}if ( gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val ) {
{
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Mods", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject7"), gdjs.Main_32Menu_32pcCode.GDNewObject7Objects1);

gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject7Objects1Objects, runtimeScene, true, false);
}if ( gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val ) {
{
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject11"), gdjs.Main_32Menu_32pcCode.GDNewObject11Objects1);
/* Reuse gdjs.Main_32Menu_32pcCode.GDNewObject7Objects1 */
{gdjs.evtTools.sound.preloadMusic(runtimeScene, "zoonitesong.mp3");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "gameOver.ogg");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "gameOverEnd.ogg");
}{for(var i = 0, len = gdjs.Main_32Menu_32pcCode.GDNewObject7Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32pcCode.GDNewObject7Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32Menu_32pcCode.GDNewObject11Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32pcCode.GDNewObject11Objects1[i].hide(false);
}
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "26 - Robotnik.mp3");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject10"), gdjs.Main_32Menu_32pcCode.GDNewObject10Objects1);

gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject10Objects1Objects, runtimeScene, true, false);
}if ( gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val ) {
{
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Inst.ogg", 2, false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("StPRITZX"), gdjs.Main_32Menu_32pcCode.GDStPRITZXObjects1);

gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDStPRITZXObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val ) {
{
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 2);
}}

}


{


gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.systemInfo.isMobile();
}if (gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu mobile", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject12"), gdjs.Main_32Menu_32pcCode.GDNewObject12Objects1);

gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject12Objects1Objects, runtimeScene, true, false);
}if ( gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val ) {
{
gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Main_32Menu_32pcCode.condition1IsTrue_0.val) {
{gdjs.evtsExt__URLTools__Redirect.func(runtimeScene, "https://gamebanana.com/wips/60325", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


{
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "255;159;0");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject14"), gdjs.Main_32Menu_32pcCode.GDNewObject14Objects1);

gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject14Objects1Objects, runtimeScene, true, false);
}if (gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeStringInJSONFile("hello", "astrogiraffe", "Hi, I'm MooseGiraffeYT and you just got moosed!");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject13"), gdjs.Main_32Menu_32pcCode.GDNewObject13Objects1);

gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32pcCode.mapOfGDgdjs_46Main_9532Menu_9532pcCode_46GDNewObject13Objects1Objects, runtimeScene, true, false);
}if (gdjs.Main_32Menu_32pcCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gamemode snif#]", false);
}}

}


};

gdjs.Main_32Menu_32pcCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32Menu_32pcCode.GDEnterObjects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDEnterObjects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDfinObjects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDfinObjects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDRoBug2Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDRoBug2Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDPlayer2Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDPlayer2Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject2Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject2Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject3Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject3Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObjectObjects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObjectObjects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject4Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject4Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject5Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject5Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject6Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject6Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject7Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject7Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject8Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject8Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject9Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject9Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDStPRITZXObjects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDStPRITZXObjects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject10Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject10Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject11Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject11Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject12Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject12Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject13Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject13Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject14Objects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewObject14Objects2.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewTextObjects1.length = 0;
gdjs.Main_32Menu_32pcCode.GDNewTextObjects2.length = 0;

gdjs.Main_32Menu_32pcCode.eventsList0(runtimeScene);

return;

}

gdjs['Main_32Menu_32pcCode'] = gdjs.Main_32Menu_32pcCode;
