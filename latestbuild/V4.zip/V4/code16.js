gdjs._49_452_32multiplayerCode = {};
gdjs._49_452_32multiplayerCode.forEachCount0_3 = 0;

gdjs._49_452_32multiplayerCode.forEachCount1_3 = 0;

gdjs._49_452_32multiplayerCode.forEachIndex3 = 0;

gdjs._49_452_32multiplayerCode.forEachObjects3 = [];

gdjs._49_452_32multiplayerCode.forEachTotalCount3 = 0;

gdjs._49_452_32multiplayerCode.GDEnterObjects1= [];
gdjs._49_452_32multiplayerCode.GDEnterObjects2= [];
gdjs._49_452_32multiplayerCode.GDEnterObjects3= [];
gdjs._49_452_32multiplayerCode.GDfinObjects1= [];
gdjs._49_452_32multiplayerCode.GDfinObjects2= [];
gdjs._49_452_32multiplayerCode.GDfinObjects3= [];
gdjs._49_452_32multiplayerCode.GDRoBug2Objects1= [];
gdjs._49_452_32multiplayerCode.GDRoBug2Objects2= [];
gdjs._49_452_32multiplayerCode.GDRoBug2Objects3= [];
gdjs._49_452_32multiplayerCode.GDPlayer2Objects1= [];
gdjs._49_452_32multiplayerCode.GDPlayer2Objects2= [];
gdjs._49_452_32multiplayerCode.GDPlayer2Objects3= [];
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1= [];
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects2= [];
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects3= [];
gdjs._49_452_32multiplayerCode.GDPlayerObjects1= [];
gdjs._49_452_32multiplayerCode.GDPlayerObjects2= [];
gdjs._49_452_32multiplayerCode.GDPlayerObjects3= [];
gdjs._49_452_32multiplayerCode.GDPlatformObjects1= [];
gdjs._49_452_32multiplayerCode.GDPlatformObjects2= [];
gdjs._49_452_32multiplayerCode.GDPlatformObjects3= [];
gdjs._49_452_32multiplayerCode.GDJumpthruObjects1= [];
gdjs._49_452_32multiplayerCode.GDJumpthruObjects2= [];
gdjs._49_452_32multiplayerCode.GDJumpthruObjects3= [];
gdjs._49_452_32multiplayerCode.GDTiledGrassPlatformObjects1= [];
gdjs._49_452_32multiplayerCode.GDTiledGrassPlatformObjects2= [];
gdjs._49_452_32multiplayerCode.GDTiledGrassPlatformObjects3= [];
gdjs._49_452_32multiplayerCode.GDTiledCastlePlatformObjects1= [];
gdjs._49_452_32multiplayerCode.GDTiledCastlePlatformObjects2= [];
gdjs._49_452_32multiplayerCode.GDTiledCastlePlatformObjects3= [];
gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1= [];
gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects2= [];
gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects3= [];
gdjs._49_452_32multiplayerCode.GDGoLeftObjects1= [];
gdjs._49_452_32multiplayerCode.GDGoLeftObjects2= [];
gdjs._49_452_32multiplayerCode.GDGoLeftObjects3= [];
gdjs._49_452_32multiplayerCode.GDGoRightObjects1= [];
gdjs._49_452_32multiplayerCode.GDGoRightObjects2= [];
gdjs._49_452_32multiplayerCode.GDGoRightObjects3= [];
gdjs._49_452_32multiplayerCode.GDLadderObjects1= [];
gdjs._49_452_32multiplayerCode.GDLadderObjects2= [];
gdjs._49_452_32multiplayerCode.GDLadderObjects3= [];
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1= [];
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2= [];
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects3= [];
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1= [];
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2= [];
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects3= [];
gdjs._49_452_32multiplayerCode.GDFlyObjects1= [];
gdjs._49_452_32multiplayerCode.GDFlyObjects2= [];
gdjs._49_452_32multiplayerCode.GDFlyObjects3= [];
gdjs._49_452_32multiplayerCode.GDBackgroundObjectsObjects1= [];
gdjs._49_452_32multiplayerCode.GDBackgroundObjectsObjects2= [];
gdjs._49_452_32multiplayerCode.GDBackgroundObjectsObjects3= [];
gdjs._49_452_32multiplayerCode.GDScoreObjects1= [];
gdjs._49_452_32multiplayerCode.GDScoreObjects2= [];
gdjs._49_452_32multiplayerCode.GDScoreObjects3= [];
gdjs._49_452_32multiplayerCode.GDCoinObjects1= [];
gdjs._49_452_32multiplayerCode.GDCoinObjects2= [];
gdjs._49_452_32multiplayerCode.GDCoinObjects3= [];
gdjs._49_452_32multiplayerCode.GDCoinIconObjects1= [];
gdjs._49_452_32multiplayerCode.GDCoinIconObjects2= [];
gdjs._49_452_32multiplayerCode.GDCoinIconObjects3= [];
gdjs._49_452_32multiplayerCode.GDLeftButtonObjects1= [];
gdjs._49_452_32multiplayerCode.GDLeftButtonObjects2= [];
gdjs._49_452_32multiplayerCode.GDLeftButtonObjects3= [];
gdjs._49_452_32multiplayerCode.GDRightButtonObjects1= [];
gdjs._49_452_32multiplayerCode.GDRightButtonObjects2= [];
gdjs._49_452_32multiplayerCode.GDRightButtonObjects3= [];
gdjs._49_452_32multiplayerCode.GDJumpButtonObjects1= [];
gdjs._49_452_32multiplayerCode.GDJumpButtonObjects2= [];
gdjs._49_452_32multiplayerCode.GDJumpButtonObjects3= [];
gdjs._49_452_32multiplayerCode.GDArrowButtonsBgObjects1= [];
gdjs._49_452_32multiplayerCode.GDArrowButtonsBgObjects2= [];
gdjs._49_452_32multiplayerCode.GDArrowButtonsBgObjects3= [];
gdjs._49_452_32multiplayerCode.GDTiledForestBackgroundObjects1= [];
gdjs._49_452_32multiplayerCode.GDTiledForestBackgroundObjects2= [];
gdjs._49_452_32multiplayerCode.GDTiledForestBackgroundObjects3= [];
gdjs._49_452_32multiplayerCode.GDCheckpointObjects1= [];
gdjs._49_452_32multiplayerCode.GDCheckpointObjects2= [];
gdjs._49_452_32multiplayerCode.GDCheckpointObjects3= [];
gdjs._49_452_32multiplayerCode.GDTopButtonObjects1= [];
gdjs._49_452_32multiplayerCode.GDTopButtonObjects2= [];
gdjs._49_452_32multiplayerCode.GDTopButtonObjects3= [];
gdjs._49_452_32multiplayerCode.GDBottomButtonObjects1= [];
gdjs._49_452_32multiplayerCode.GDBottomButtonObjects2= [];
gdjs._49_452_32multiplayerCode.GDBottomButtonObjects3= [];
gdjs._49_452_32multiplayerCode.GDFadeInObjects1= [];
gdjs._49_452_32multiplayerCode.GDFadeInObjects2= [];
gdjs._49_452_32multiplayerCode.GDFadeInObjects3= [];
gdjs._49_452_32multiplayerCode.GDNewObjectObjects1= [];
gdjs._49_452_32multiplayerCode.GDNewObjectObjects2= [];
gdjs._49_452_32multiplayerCode.GDNewObjectObjects3= [];

gdjs._49_452_32multiplayerCode.conditionTrue_0 = {val:false};
gdjs._49_452_32multiplayerCode.condition0IsTrue_0 = {val:false};
gdjs._49_452_32multiplayerCode.condition1IsTrue_0 = {val:false};
gdjs._49_452_32multiplayerCode.condition2IsTrue_0 = {val:false};
gdjs._49_452_32multiplayerCode.conditionTrue_1 = {val:false};
gdjs._49_452_32multiplayerCode.condition0IsTrue_1 = {val:false};
gdjs._49_452_32multiplayerCode.condition1IsTrue_1 = {val:false};
gdjs._49_452_32multiplayerCode.condition2IsTrue_1 = {val:false};


gdjs._49_452_32multiplayerCode.eventsList0 = function(runtimeScene) {

{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
{gdjs._49_452_32multiplayerCode.conditionTrue_1 = gdjs._49_452_32multiplayerCode.condition0IsTrue_0;
gdjs._49_452_32multiplayerCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17869908);
}
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}}

}


};gdjs._49_452_32multiplayerCode.eventsList1 = function(runtimeScene) {

{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
{gdjs._49_452_32multiplayerCode.conditionTrue_1 = gdjs._49_452_32multiplayerCode.condition0IsTrue_0;
gdjs._49_452_32multiplayerCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17871324);
}
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}}

}


};gdjs._49_452_32multiplayerCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1, gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2);


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( !(gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[k] = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerObjects2[i].setAnimationName("Idle");
}
}}

}


{

/* Reuse gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1 */

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerObjects1[i].setAnimationName("Running");
}
}}

}


};gdjs._49_452_32multiplayerCode.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1 */

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length;i<l;++i) {
    if ( !(gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs._49_452_32multiplayerCode.GDPlayer2Objects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2Objects1[i].setAnimationName("Idle");
}
}}

}


};gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDGoLeftObjects1Objects = Hashtable.newFrom({"GoLeft": gdjs._49_452_32multiplayerCode.GDGoLeftObjects1});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDGoRightObjects1Objects = Hashtable.newFrom({"GoRight": gdjs._49_452_32multiplayerCode.GDGoRightObjects1});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDGoLeftObjects2Objects = Hashtable.newFrom({"GoLeft": gdjs._49_452_32multiplayerCode.GDGoLeftObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDSlimeWalkObjects2ObjectsGDgdjs_46_9549_95452_9532multiplayerCode_46GDFlyObjects2Objects = Hashtable.newFrom({"SlimeWalk": gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2, "Fly": gdjs._49_452_32multiplayerCode.GDFlyObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDGoRightObjects2Objects = Hashtable.newFrom({"GoRight": gdjs._49_452_32multiplayerCode.GDGoRightObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDSlimeWalkObjects2ObjectsGDgdjs_46_9549_95452_9532multiplayerCode_46GDFlyObjects2Objects = Hashtable.newFrom({"SlimeWalk": gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2, "Fly": gdjs._49_452_32multiplayerCode.GDFlyObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46_9549_95452_9532multiplayerCode_46GDFlyObjects1Objects = Hashtable.newFrom({"SlimeWalk": gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1, "Fly": gdjs._49_452_32multiplayerCode.GDFlyObjects1});
gdjs._49_452_32multiplayerCode.eventsList4 = function(runtimeScene) {

};gdjs._49_452_32multiplayerCode.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs._49_452_32multiplayerCode.GDFlyObjects2 */
/* Reuse gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2 */

gdjs._49_452_32multiplayerCode.forEachTotalCount3 = 0;
gdjs._49_452_32multiplayerCode.forEachObjects3.length = 0;
gdjs._49_452_32multiplayerCode.forEachCount0_3 = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length;
gdjs._49_452_32multiplayerCode.forEachTotalCount3 += gdjs._49_452_32multiplayerCode.forEachCount0_3;
gdjs._49_452_32multiplayerCode.forEachObjects3.push.apply(gdjs._49_452_32multiplayerCode.forEachObjects3,gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2);
gdjs._49_452_32multiplayerCode.forEachCount1_3 = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length;
gdjs._49_452_32multiplayerCode.forEachTotalCount3 += gdjs._49_452_32multiplayerCode.forEachCount1_3;
gdjs._49_452_32multiplayerCode.forEachObjects3.push.apply(gdjs._49_452_32multiplayerCode.forEachObjects3,gdjs._49_452_32multiplayerCode.GDFlyObjects2);
for(gdjs._49_452_32multiplayerCode.forEachIndex3 = 0;gdjs._49_452_32multiplayerCode.forEachIndex3 < gdjs._49_452_32multiplayerCode.forEachTotalCount3;++gdjs._49_452_32multiplayerCode.forEachIndex3) {
gdjs._49_452_32multiplayerCode.GDFlyObjects3.length = 0;

gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects3.length = 0;


if (gdjs._49_452_32multiplayerCode.forEachIndex3 < gdjs._49_452_32multiplayerCode.forEachCount0_3) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects3.push(gdjs._49_452_32multiplayerCode.forEachObjects3[gdjs._49_452_32multiplayerCode.forEachIndex3]);
}
else if (gdjs._49_452_32multiplayerCode.forEachIndex3 < gdjs._49_452_32multiplayerCode.forEachCount0_3+gdjs._49_452_32multiplayerCode.forEachCount1_3) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects3.push(gdjs._49_452_32multiplayerCode.forEachObjects3[gdjs._49_452_32multiplayerCode.forEachIndex3]);
}
if (true) {
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}
}

}


};gdjs._49_452_32multiplayerCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1, gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2);


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[k] = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDFlyObjects1, gdjs._49_452_32multiplayerCode.GDFlyObjects2);

/* Reuse gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2 */
gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1, gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2);

{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].setAnimation(1);
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].activateBehavior("PlatformerObject", true);
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].activateBehavior("PlatformerObject", true);
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").setGravity(1500);
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].getBehavior("PlatformerObject").setGravity(1500);
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}
{ //Subevents
gdjs._49_452_32multiplayerCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1 */

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( !(gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


};gdjs._49_452_32multiplayerCode.eventsList7 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDFlyObjects1, gdjs._49_452_32multiplayerCode.GDFlyObjects2);

gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs._49_452_32multiplayerCode.GDGoLeftObjects2);
gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1, gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2);


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDGoLeftObjects2Objects, gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDSlimeWalkObjects2ObjectsGDgdjs_46_9549_95452_9532multiplayerCode_46GDFlyObjects2Objects, false, runtimeScene, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_452_32multiplayerCode.GDFlyObjects2 */
/* Reuse gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].returnVariable(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")).setNumber(1);
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].returnVariable(gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].getVariables().get("GoingLeft")).setNumber(1);
}
}}

}


{

gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDFlyObjects1, gdjs._49_452_32multiplayerCode.GDFlyObjects2);

gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs._49_452_32multiplayerCode.GDGoRightObjects2);
gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1, gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2);


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDGoRightObjects2Objects, gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDSlimeWalkObjects2ObjectsGDgdjs_46_9549_95452_9532multiplayerCode_46GDFlyObjects2Objects, false, runtimeScene, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_452_32multiplayerCode.GDFlyObjects2 */
/* Reuse gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].returnVariable(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")).setNumber(0);
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].returnVariable(gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].getVariables().get("GoingLeft")).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDFlyObjects1, gdjs._49_452_32multiplayerCode.GDFlyObjects2);

gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1, gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2);


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[k] = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].getVariableNumber(gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDFlyObjects2[k] = gdjs._49_452_32multiplayerCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDFlyObjects2.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_452_32multiplayerCode.GDFlyObjects2 */
/* Reuse gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDFlyObjects1, gdjs._49_452_32multiplayerCode.GDFlyObjects2);

gdjs.copyArray(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1, gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2);


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[k] = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].getVariableNumber(gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDFlyObjects2[k] = gdjs._49_452_32multiplayerCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDFlyObjects2.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_452_32multiplayerCode.GDFlyObjects2 */
/* Reuse gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects2[i].flipX(true);
}
}}

}


{



}


{

/* Reuse gdjs._49_452_32multiplayerCode.GDFlyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);
/* Reuse gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1 */

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDPlayerHitBoxObjects1Objects, gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46_9549_95452_9532multiplayerCode_46GDFlyObjects1Objects, false, runtimeScene, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs._49_452_32multiplayerCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs._49_452_32multiplayerCode.GDCoinObjects1});
gdjs._49_452_32multiplayerCode.eventsList8 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs._49_452_32multiplayerCode.GDScoreObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDScoreObjects1[i].setString("x " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


};gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDLeftButtonObjects2Objects = Hashtable.newFrom({"LeftButton": gdjs._49_452_32multiplayerCode.GDLeftButtonObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDRightButtonObjects2Objects = Hashtable.newFrom({"RightButton": gdjs._49_452_32multiplayerCode.GDRightButtonObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDTopButtonObjects2Objects = Hashtable.newFrom({"TopButton": gdjs._49_452_32multiplayerCode.GDTopButtonObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDBottomButtonObjects2Objects = Hashtable.newFrom({"BottomButton": gdjs._49_452_32multiplayerCode.GDBottomButtonObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDJumpButtonObjects1Objects = Hashtable.newFrom({"JumpButton": gdjs._49_452_32multiplayerCode.GDJumpButtonObjects1});
gdjs._49_452_32multiplayerCode.eventsList9 = function(runtimeScene) {

{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ArrowButtonsBg"), gdjs._49_452_32multiplayerCode.GDArrowButtonsBgObjects2);
gdjs.copyArray(runtimeScene.getObjects("BottomButton"), gdjs._49_452_32multiplayerCode.GDBottomButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs._49_452_32multiplayerCode.GDJumpButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs._49_452_32multiplayerCode.GDLeftButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs._49_452_32multiplayerCode.GDRightButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs._49_452_32multiplayerCode.GDTopButtonObjects2);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDLeftButtonObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDLeftButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDRightButtonObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDRightButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDJumpButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDArrowButtonsBgObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDArrowButtonsBgObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDTopButtonObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDTopButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDBottomButtonObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDBottomButtonObjects2[i].hide();
}
}}

}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs._49_452_32multiplayerCode.GDLeftButtonObjects2);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDLeftButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs._49_452_32multiplayerCode.GDRightButtonObjects2);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDRightButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs._49_452_32multiplayerCode.GDTopButtonObjects2);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDTopButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateUpKey();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateLadderKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BottomButton"), gdjs._49_452_32multiplayerCode.GDBottomButtonObjects2);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDBottomButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateDownKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs._49_452_32multiplayerCode.GDJumpButtonObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDJumpButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDPlayerHitBoxObjects2Objects = Hashtable.newFrom({"PlayerHitBox": gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs._49_452_32multiplayerCode.GDCheckpointObjects2});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDFadeInObjects2Objects = Hashtable.newFrom({"FadeIn": gdjs._49_452_32multiplayerCode.GDFadeInObjects2});
gdjs._49_452_32multiplayerCode.eventsList10 = function(runtimeScene) {

{



}


{


{
gdjs._49_452_32multiplayerCode.GDFadeInObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDFadeInObjects2Objects, 0, 0, "GUI");
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFadeInObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFadeInObjects2[i].setWidth(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene));
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFadeInObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFadeInObjects2[i].setHeight(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene));
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFadeInObjects2.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFadeInObjects2[i].getBehavior("Tween").addObjectOpacityTween("FadeIn", 0, "easeInQuad", 1500, true);
}
}}

}


};gdjs._49_452_32multiplayerCode.eventsList11 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs._49_452_32multiplayerCode.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDPlayerHitBoxObjects2Objects, gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDCheckpointObjects2Objects, false, runtimeScene, false);
}if ( gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val ) {
{
{gdjs._49_452_32multiplayerCode.conditionTrue_1 = gdjs._49_452_32multiplayerCode.condition1IsTrue_0;
gdjs._49_452_32multiplayerCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17897956);
}
}}
if (gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val) {
/* Reuse gdjs._49_452_32multiplayerCode.GDCheckpointObjects2 */
{runtimeScene.getVariables().getFromIndex(1).setNumber((( gdjs._49_452_32multiplayerCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs._49_452_32multiplayerCode.GDCheckpointObjects2[0].getPointX("")));
}{runtimeScene.getVariables().getFromIndex(2).setNumber((( gdjs._49_452_32multiplayerCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs._49_452_32multiplayerCode.GDCheckpointObjects2[0].getPointY("")));
}}

}


{



}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 1;
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "life lost sound.wav", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Over", true);
}
{ //Subevents
gdjs._49_452_32multiplayerCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i].getY() > 1000 ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[k] = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2HitBox"), gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects2);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects2.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects2[i].getY() > 1000 ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects2[k] = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects2[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects2.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


{



}


};gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDfinObjects1Objects = Hashtable.newFrom({"fin": gdjs._49_452_32multiplayerCode.GDfinObjects1});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_452_32multiplayerCode.GDPlayerObjects1});
gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDCoinIconObjects1Objects = Hashtable.newFrom({"CoinIcon": gdjs._49_452_32multiplayerCode.GDCoinIconObjects1});
gdjs._49_452_32multiplayerCode.eventsList12 = function(runtimeScene) {

{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player2HitBox"), gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs._49_452_32multiplayerCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerObjects1[i].setPosition((( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[0].getPointX("")) - 12,(( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2Objects1[i].setPosition((( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[0].getPointX("")) - 12,(( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[0].getPointY("")));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}
{ //Subevents
gdjs._49_452_32multiplayerCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2HitBox"), gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs._49_452_32multiplayerCode.GDPlayer2Objects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2Objects1[i].setAnimationName("Jumping");
}
}
{ //Subevents
gdjs._49_452_32multiplayerCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2HitBox"), gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs._49_452_32multiplayerCode.GDPlayer2Objects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2Objects1[i].setAnimationName("Jumping");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs._49_452_32multiplayerCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2HitBox"), gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs._49_452_32multiplayerCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[k] = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}}

}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerObjects1[i].flipX(true);
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateLadderKey();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateUpKey();
}
}}

}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player2HitBox"), gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].getBehavior("PlatformerObject").simulateLadderKey();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].getBehavior("PlatformerObject").simulateUpKey();
}
}}

}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs._49_452_32multiplayerCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2HitBox"), gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2Objects1[i].flipX(true);
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs._49_452_32multiplayerCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2HitBox"), gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2Objects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs._49_452_32multiplayerCode.GDPlayer2Objects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs._49_452_32multiplayerCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs._49_452_32multiplayerCode.GDPlayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs._49_452_32multiplayerCode.GDPlayer2Objects1.length === 0 ) ? 0 :gdjs._49_452_32multiplayerCode.GDPlayer2Objects1[0].getPointX("")), "", 0);
}}

}


{



}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs._49_452_32multiplayerCode.GDGoLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs._49_452_32multiplayerCode.GDGoRightObjects1);
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDGoLeftObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDGoLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDGoRightObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDGoRightObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs._49_452_32multiplayerCode.GDGoLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform"), gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDGoLeftObjects1Objects, gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1[i].addForce(-(150), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs._49_452_32multiplayerCode.GDGoRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform"), gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDGoRightObjects1Objects, gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1[i].addForce(150, 0, 1);
}
}}

}


{



}


{



}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs._49_452_32multiplayerCode.GDFlyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SlimeWalk"), gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[i].isCurrentAnimationName("Dead")) ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[k] = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDFlyObjects1.length;i<l;++i) {
    if ( !(gdjs._49_452_32multiplayerCode.GDFlyObjects1[i].isCurrentAnimationName("Dead")) ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDFlyObjects1[k] = gdjs._49_452_32multiplayerCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDFlyObjects1.length = k;}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs._49_452_32multiplayerCode.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs._49_452_32multiplayerCode.GDFlyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SlimeWalk"), gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[i].isCurrentAnimationName("Dead") ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[k] = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDFlyObjects1[i].isCurrentAnimationName("Dead") ) {
        gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDFlyObjects1[k] = gdjs._49_452_32multiplayerCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDFlyObjects1.length = k;}if ( gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[i].getBehavior("Tween").isPlaying("FadeOut")) ) {
        gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[k] = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDFlyObjects1.length;i<l;++i) {
    if ( !(gdjs._49_452_32multiplayerCode.GDFlyObjects1[i].getBehavior("Tween").isPlaying("FadeOut")) ) {
        gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDFlyObjects1[k] = gdjs._49_452_32multiplayerCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDFlyObjects1.length = k;}}
if (gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val) {
/* Reuse gdjs._49_452_32multiplayerCode.GDFlyObjects1 */
/* Reuse gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1 */
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeOutQuad", 1500, true);
}
for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDFlyObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeOutQuad", 1500, true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs._49_452_32multiplayerCode.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDPlayerHitBoxObjects1Objects, gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDCoinObjects1Objects, false, runtimeScene, false);
}if ( gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._49_452_32multiplayerCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs._49_452_32multiplayerCode.GDCoinObjects1[i].getOpacity() == 255 ) {
        gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val = true;
        gdjs._49_452_32multiplayerCode.GDCoinObjects1[k] = gdjs._49_452_32multiplayerCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs._49_452_32multiplayerCode.GDCoinObjects1.length = k;}}
if (gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val) {
/* Reuse gdjs._49_452_32multiplayerCode.GDCoinObjects1 */
{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDCoinObjects1[i].setOpacity(254);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDCoinObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeInQuad", 700, true);
}
}{for(var i = 0, len = gdjs._49_452_32multiplayerCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs._49_452_32multiplayerCode.GDCoinObjects1[i].getBehavior("Tween").addObjectPositionYTween("MoveUp", (gdjs._49_452_32multiplayerCode.GDCoinObjects1[i].getPointY("")) - 50, "easeOutQuad", 700, false);
}
}}

}


{


gdjs._49_452_32multiplayerCode.eventsList8(runtimeScene);
}


{


gdjs._49_452_32multiplayerCode.eventsList9(runtimeScene);
}


{


gdjs._49_452_32multiplayerCode.eventsList11(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_452_32multiplayerCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("fin"), gdjs._49_452_32multiplayerCode.GDfinObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDfinObjects1Objects, gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Coming Soon", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CoinIcon"), gdjs._49_452_32multiplayerCode.GDCoinIconObjects1);

gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_452_32multiplayerCode.mapOfGDgdjs_46_9549_95452_9532multiplayerCode_46GDCoinIconObjects1Objects, runtimeScene, true, false);
}if ( gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val ) {
{
gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs._49_452_32multiplayerCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Pause");
}}

}


{


gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = false;
{
gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_452_32multiplayerCode.condition0IsTrue_0.val) {
{gdjs.evtTools.window.setWindowTitle(runtimeScene, "Giraffe the Big Nosed Giraffe Multiplayer -- 1-2");
}}

}


};

gdjs._49_452_32multiplayerCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49_452_32multiplayerCode.GDEnterObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDEnterObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDEnterObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDfinObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDfinObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDfinObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDRoBug2Objects1.length = 0;
gdjs._49_452_32multiplayerCode.GDRoBug2Objects2.length = 0;
gdjs._49_452_32multiplayerCode.GDRoBug2Objects3.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayer2Objects1.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayer2Objects2.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayer2Objects3.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayer2HitBoxObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayerObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayerObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayerObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDPlatformObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDPlatformObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDPlatformObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDJumpthruObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDJumpthruObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDJumpthruObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDTiledGrassPlatformObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDTiledGrassPlatformObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDTiledGrassPlatformObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDTiledCastlePlatformObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDTiledCastlePlatformObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDTiledCastlePlatformObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDMovingPlatformObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDGoLeftObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDGoLeftObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDGoLeftObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDGoRightObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDGoRightObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDGoRightObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDLadderObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDLadderObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDLadderObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDPlayerHitBoxObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDSlimeWalkObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDFlyObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDFlyObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDFlyObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDBackgroundObjectsObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDBackgroundObjectsObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDBackgroundObjectsObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDScoreObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDScoreObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDScoreObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDCoinObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDCoinObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDCoinObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDCoinIconObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDCoinIconObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDCoinIconObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDLeftButtonObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDLeftButtonObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDLeftButtonObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDRightButtonObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDRightButtonObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDRightButtonObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDJumpButtonObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDJumpButtonObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDJumpButtonObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDArrowButtonsBgObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDArrowButtonsBgObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDArrowButtonsBgObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDTiledForestBackgroundObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDTiledForestBackgroundObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDTiledForestBackgroundObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDCheckpointObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDCheckpointObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDCheckpointObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDTopButtonObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDTopButtonObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDTopButtonObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDBottomButtonObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDBottomButtonObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDBottomButtonObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDFadeInObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDFadeInObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDFadeInObjects3.length = 0;
gdjs._49_452_32multiplayerCode.GDNewObjectObjects1.length = 0;
gdjs._49_452_32multiplayerCode.GDNewObjectObjects2.length = 0;
gdjs._49_452_32multiplayerCode.GDNewObjectObjects3.length = 0;

gdjs._49_452_32multiplayerCode.eventsList12(runtimeScene);

return;

}

gdjs['_49_452_32multiplayerCode'] = gdjs._49_452_32multiplayerCode;
