gdjs._49_453_32begin_32sceneCode = {};
gdjs._49_453_32begin_32sceneCode.GDEnterObjects1= [];
gdjs._49_453_32begin_32sceneCode.GDEnterObjects2= [];
gdjs._49_453_32begin_32sceneCode.GDfinObjects1= [];
gdjs._49_453_32begin_32sceneCode.GDfinObjects2= [];
gdjs._49_453_32begin_32sceneCode.GDRoBug2Objects1= [];
gdjs._49_453_32begin_32sceneCode.GDRoBug2Objects2= [];
gdjs._49_453_32begin_32sceneCode.GDPlayer2Objects1= [];
gdjs._49_453_32begin_32sceneCode.GDPlayer2Objects2= [];
gdjs._49_453_32begin_32sceneCode.GDPlayer2HitBoxObjects1= [];
gdjs._49_453_32begin_32sceneCode.GDPlayer2HitBoxObjects2= [];
gdjs._49_453_32begin_32sceneCode.GDtipObjects1= [];
gdjs._49_453_32begin_32sceneCode.GDtipObjects2= [];
gdjs._49_453_32begin_32sceneCode.GDNewObjectObjects1= [];
gdjs._49_453_32begin_32sceneCode.GDNewObjectObjects2= [];
gdjs._49_453_32begin_32sceneCode.GDNewObject2Objects1= [];
gdjs._49_453_32begin_32sceneCode.GDNewObject2Objects2= [];

gdjs._49_453_32begin_32sceneCode.conditionTrue_0 = {val:false};
gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs._49_453_32begin_32sceneCode.condition1IsTrue_0 = {val:false};


gdjs._49_453_32begin_32sceneCode.mapOfGDgdjs_46_9549_95453_9532begin_9532sceneCode_46GDEnterObjects1Objects = Hashtable.newFrom({"Enter": gdjs._49_453_32begin_32sceneCode.GDEnterObjects1});
gdjs._49_453_32begin_32sceneCode.eventsList0 = function(runtimeScene) {

{


gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1-3", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs._49_453_32begin_32sceneCode.GDEnterObjects1);

gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_453_32begin_32sceneCode.mapOfGDgdjs_46_9549_95453_9532begin_9532sceneCode_46GDEnterObjects1Objects, runtimeScene, true, false);
}if (gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1-3", false);
}}

}


{


gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs._49_453_32begin_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs._49_453_32begin_32sceneCode.GDEnterObjects1);
{for(var i = 0, len = gdjs._49_453_32begin_32sceneCode.GDEnterObjects1.length ;i < len;++i) {
    gdjs._49_453_32begin_32sceneCode.GDEnterObjects1[i].hide();
}
}}

}


};

gdjs._49_453_32begin_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49_453_32begin_32sceneCode.GDEnterObjects1.length = 0;
gdjs._49_453_32begin_32sceneCode.GDEnterObjects2.length = 0;
gdjs._49_453_32begin_32sceneCode.GDfinObjects1.length = 0;
gdjs._49_453_32begin_32sceneCode.GDfinObjects2.length = 0;
gdjs._49_453_32begin_32sceneCode.GDRoBug2Objects1.length = 0;
gdjs._49_453_32begin_32sceneCode.GDRoBug2Objects2.length = 0;
gdjs._49_453_32begin_32sceneCode.GDPlayer2Objects1.length = 0;
gdjs._49_453_32begin_32sceneCode.GDPlayer2Objects2.length = 0;
gdjs._49_453_32begin_32sceneCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs._49_453_32begin_32sceneCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs._49_453_32begin_32sceneCode.GDtipObjects1.length = 0;
gdjs._49_453_32begin_32sceneCode.GDtipObjects2.length = 0;
gdjs._49_453_32begin_32sceneCode.GDNewObjectObjects1.length = 0;
gdjs._49_453_32begin_32sceneCode.GDNewObjectObjects2.length = 0;
gdjs._49_453_32begin_32sceneCode.GDNewObject2Objects1.length = 0;
gdjs._49_453_32begin_32sceneCode.GDNewObject2Objects2.length = 0;

gdjs._49_453_32begin_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['_49_453_32begin_32sceneCode'] = gdjs._49_453_32begin_32sceneCode;
