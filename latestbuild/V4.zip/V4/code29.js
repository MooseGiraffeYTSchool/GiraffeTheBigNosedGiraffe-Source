gdjs.Gamemode_32snif_35_93Code = {};
gdjs.Gamemode_32snif_35_93Code.GDEnterObjects1= [];
gdjs.Gamemode_32snif_35_93Code.GDEnterObjects2= [];
gdjs.Gamemode_32snif_35_93Code.GDEnterObjects3= [];
gdjs.Gamemode_32snif_35_93Code.GDfinObjects1= [];
gdjs.Gamemode_32snif_35_93Code.GDfinObjects2= [];
gdjs.Gamemode_32snif_35_93Code.GDfinObjects3= [];
gdjs.Gamemode_32snif_35_93Code.GDRoBug2Objects1= [];
gdjs.Gamemode_32snif_35_93Code.GDRoBug2Objects2= [];
gdjs.Gamemode_32snif_35_93Code.GDRoBug2Objects3= [];
gdjs.Gamemode_32snif_35_93Code.GDPlayer2Objects1= [];
gdjs.Gamemode_32snif_35_93Code.GDPlayer2Objects2= [];
gdjs.Gamemode_32snif_35_93Code.GDPlayer2Objects3= [];
gdjs.Gamemode_32snif_35_93Code.GDPlayer2HitBoxObjects1= [];
gdjs.Gamemode_32snif_35_93Code.GDPlayer2HitBoxObjects2= [];
gdjs.Gamemode_32snif_35_93Code.GDPlayer2HitBoxObjects3= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject2Objects1= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject2Objects2= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject2Objects3= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObjectObjects1= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObjectObjects2= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObjectObjects3= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject3Objects1= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject3Objects2= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject3Objects3= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject4Objects1= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject4Objects2= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject4Objects3= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject5Objects1= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject5Objects2= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject5Objects3= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject6Objects1= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject6Objects2= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject6Objects3= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject7Objects1= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject7Objects2= [];
gdjs.Gamemode_32snif_35_93Code.GDNewObject7Objects3= [];

gdjs.Gamemode_32snif_35_93Code.conditionTrue_0 = {val:false};
gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0 = {val:false};
gdjs.Gamemode_32snif_35_93Code.condition1IsTrue_0 = {val:false};
gdjs.Gamemode_32snif_35_93Code.condition2IsTrue_0 = {val:false};


gdjs.Gamemode_32snif_35_93Code.mapOfGDgdjs_46Gamemode_9532snif_9535_9593Code_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.Gamemode_32snif_35_93Code.GDNewObjectObjects1});
gdjs.Gamemode_32snif_35_93Code.mapOfGDgdjs_46Gamemode_9532snif_9535_9593Code_46GDNewObject6Objects1Objects = Hashtable.newFrom({"NewObject6": gdjs.Gamemode_32snif_35_93Code.GDNewObject6Objects1});
gdjs.Gamemode_32snif_35_93Code.eventsList0 = function(runtimeScene) {

{


gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = false;
{
gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
}if (gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu mobile", false);
}}

}


{


gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = false;
{
gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu pc", false);
}}

}


};gdjs.Gamemode_32snif_35_93Code.mapOfGDgdjs_46Gamemode_9532snif_9535_9593Code_46GDNewObject7Objects1Objects = Hashtable.newFrom({"NewObject7": gdjs.Gamemode_32snif_35_93Code.GDNewObject7Objects1});
gdjs.Gamemode_32snif_35_93Code.eventsList1 = function(runtimeScene) {

{


gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = false;
{
gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "Blue");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.Gamemode_32snif_35_93Code.GDNewObjectObjects1);

gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = false;
gdjs.Gamemode_32snif_35_93Code.condition1IsTrue_0.val = false;
{
gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Gamemode_32snif_35_93Code.mapOfGDgdjs_46Gamemode_9532snif_9535_9593Code_46GDNewObjectObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val ) {
{
gdjs.Gamemode_32snif_35_93Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Gamemode_32snif_35_93Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1 begin scene multi", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject6"), gdjs.Gamemode_32snif_35_93Code.GDNewObject6Objects1);

gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = false;
{
gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Gamemode_32snif_35_93Code.mapOfGDgdjs_46Gamemode_9532snif_9535_9593Code_46GDNewObject6Objects1Objects, runtimeScene, true, false);
}if (gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Gamemode_32snif_35_93Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject7"), gdjs.Gamemode_32snif_35_93Code.GDNewObject7Objects1);

gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = false;
gdjs.Gamemode_32snif_35_93Code.condition1IsTrue_0.val = false;
{
gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Gamemode_32snif_35_93Code.mapOfGDgdjs_46Gamemode_9532snif_9535_9593Code_46GDNewObject7Objects1Objects, runtimeScene, true, false);
}if ( gdjs.Gamemode_32snif_35_93Code.condition0IsTrue_0.val ) {
{
gdjs.Gamemode_32snif_35_93Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Gamemode_32snif_35_93Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1 begin scene", false);
}}

}


};

gdjs.Gamemode_32snif_35_93Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Gamemode_32snif_35_93Code.GDEnterObjects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDEnterObjects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDEnterObjects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDfinObjects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDfinObjects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDfinObjects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDRoBug2Objects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDRoBug2Objects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDRoBug2Objects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDPlayer2Objects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDPlayer2Objects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDPlayer2Objects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDPlayer2HitBoxObjects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDPlayer2HitBoxObjects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDPlayer2HitBoxObjects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject2Objects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject2Objects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject2Objects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObjectObjects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObjectObjects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObjectObjects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject3Objects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject3Objects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject3Objects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject4Objects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject4Objects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject4Objects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject5Objects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject5Objects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject5Objects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject6Objects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject6Objects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject6Objects3.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject7Objects1.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject7Objects2.length = 0;
gdjs.Gamemode_32snif_35_93Code.GDNewObject7Objects3.length = 0;

gdjs.Gamemode_32snif_35_93Code.eventsList1(runtimeScene);

return;

}

gdjs['Gamemode_32snif_35_93Code'] = gdjs.Gamemode_32snif_35_93Code;
