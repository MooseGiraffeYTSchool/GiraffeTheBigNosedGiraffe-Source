gdjs.Cutscene_33Code = {};

gdjs.Cutscene_33Code.conditionTrue_0 = {val:false};
gdjs.Cutscene_33Code.condition0IsTrue_0 = {val:false};


gdjs.Cutscene_33Code.eventsList0 = function(runtimeScene) {

};

gdjs.Cutscene_33Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.Cutscene_33Code.eventsList0(runtimeScene);

return;

}

gdjs['Cutscene_33Code'] = gdjs.Cutscene_33Code;
