gdjs.RobugCode = {};
gdjs.RobugCode.GDEnterObjects1= [];
gdjs.RobugCode.GDEnterObjects2= [];
gdjs.RobugCode.GDfinObjects1= [];
gdjs.RobugCode.GDfinObjects2= [];
gdjs.RobugCode.GDRoBug2Objects1= [];
gdjs.RobugCode.GDRoBug2Objects2= [];
gdjs.RobugCode.GDPlayer2Objects1= [];
gdjs.RobugCode.GDPlayer2Objects2= [];
gdjs.RobugCode.GDPlayer2HitBoxObjects1= [];
gdjs.RobugCode.GDPlayer2HitBoxObjects2= [];
gdjs.RobugCode.GDNewObject3Objects1= [];
gdjs.RobugCode.GDNewObject3Objects2= [];
gdjs.RobugCode.GDNewObject2Objects1= [];
gdjs.RobugCode.GDNewObject2Objects2= [];
gdjs.RobugCode.GDNewObjectObjects1= [];
gdjs.RobugCode.GDNewObjectObjects2= [];

gdjs.RobugCode.conditionTrue_0 = {val:false};
gdjs.RobugCode.condition0IsTrue_0 = {val:false};
gdjs.RobugCode.condition1IsTrue_0 = {val:false};


gdjs.RobugCode.eventsList0 = function(runtimeScene) {

{


gdjs.RobugCode.condition0IsTrue_0.val = false;
{
gdjs.RobugCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.RobugCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject2"), gdjs.RobugCode.GDNewObject2Objects1);
{for(var i = 0, len = gdjs.RobugCode.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs.RobugCode.GDNewObject2Objects1[i].hide();
}
}}

}


{


gdjs.RobugCode.condition0IsTrue_0.val = false;
{
gdjs.RobugCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "Introduce");
}if (gdjs.RobugCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject2"), gdjs.RobugCode.GDNewObject2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewObject3"), gdjs.RobugCode.GDNewObject3Objects1);
{for(var i = 0, len = gdjs.RobugCode.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs.RobugCode.GDNewObject2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RobugCode.GDNewObject3Objects1.length ;i < len;++i) {
    gdjs.RobugCode.GDNewObject3Objects1[i].hide();
}
}}

}


{


gdjs.RobugCode.condition0IsTrue_0.val = false;
{
gdjs.RobugCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "Introduce");
}if (gdjs.RobugCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1-3 part 2", false);
}}

}


};

gdjs.RobugCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.RobugCode.GDEnterObjects1.length = 0;
gdjs.RobugCode.GDEnterObjects2.length = 0;
gdjs.RobugCode.GDfinObjects1.length = 0;
gdjs.RobugCode.GDfinObjects2.length = 0;
gdjs.RobugCode.GDRoBug2Objects1.length = 0;
gdjs.RobugCode.GDRoBug2Objects2.length = 0;
gdjs.RobugCode.GDPlayer2Objects1.length = 0;
gdjs.RobugCode.GDPlayer2Objects2.length = 0;
gdjs.RobugCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.RobugCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.RobugCode.GDNewObject3Objects1.length = 0;
gdjs.RobugCode.GDNewObject3Objects2.length = 0;
gdjs.RobugCode.GDNewObject2Objects1.length = 0;
gdjs.RobugCode.GDNewObject2Objects2.length = 0;
gdjs.RobugCode.GDNewObjectObjects1.length = 0;
gdjs.RobugCode.GDNewObjectObjects2.length = 0;

gdjs.RobugCode.eventsList0(runtimeScene);

return;

}

gdjs['RobugCode'] = gdjs.RobugCode;
