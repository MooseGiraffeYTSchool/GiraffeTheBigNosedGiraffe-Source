gdjs.ControlsCode = {};

gdjs.ControlsCode.conditionTrue_0 = {val:false};
gdjs.ControlsCode.condition0IsTrue_0 = {val:false};


gdjs.ControlsCode.eventsList0 = function(runtimeScene) {

};

gdjs.ControlsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.ControlsCode.eventsList0(runtimeScene);

return;

}

gdjs['ControlsCode'] = gdjs.ControlsCode;
