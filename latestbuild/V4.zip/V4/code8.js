gdjs.Game_32Over_32multiCode = {};
gdjs.Game_32Over_32multiCode.GDEnterObjects1= [];
gdjs.Game_32Over_32multiCode.GDEnterObjects2= [];
gdjs.Game_32Over_32multiCode.GDfinObjects1= [];
gdjs.Game_32Over_32multiCode.GDfinObjects2= [];
gdjs.Game_32Over_32multiCode.GDRoBug2Objects1= [];
gdjs.Game_32Over_32multiCode.GDRoBug2Objects2= [];
gdjs.Game_32Over_32multiCode.GDPlayer2Objects1= [];
gdjs.Game_32Over_32multiCode.GDPlayer2Objects2= [];
gdjs.Game_32Over_32multiCode.GDPlayer2HitBoxObjects1= [];
gdjs.Game_32Over_32multiCode.GDPlayer2HitBoxObjects2= [];
gdjs.Game_32Over_32multiCode.GDNewObjectObjects1= [];
gdjs.Game_32Over_32multiCode.GDNewObjectObjects2= [];
gdjs.Game_32Over_32multiCode.GDNewObject2Objects1= [];
gdjs.Game_32Over_32multiCode.GDNewObject2Objects2= [];
gdjs.Game_32Over_32multiCode.GDNewObject3Objects1= [];
gdjs.Game_32Over_32multiCode.GDNewObject3Objects2= [];
gdjs.Game_32Over_32multiCode.GDNewObject4Objects1= [];
gdjs.Game_32Over_32multiCode.GDNewObject4Objects2= [];

gdjs.Game_32Over_32multiCode.conditionTrue_0 = {val:false};
gdjs.Game_32Over_32multiCode.condition0IsTrue_0 = {val:false};
gdjs.Game_32Over_32multiCode.condition1IsTrue_0 = {val:false};


gdjs.Game_32Over_32multiCode.eventsList0 = function(runtimeScene) {

{


{
}

}


{


gdjs.Game_32Over_32multiCode.condition0IsTrue_0.val = false;
{
gdjs.Game_32Over_32multiCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Game_32Over_32multiCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "gameOver.ogg", 1, true, 100, 1);
}}

}


{


gdjs.Game_32Over_32multiCode.condition0IsTrue_0.val = false;
{
gdjs.Game_32Over_32multiCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Return");
}if (gdjs.Game_32Over_32multiCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "gameOverEnd.ogg", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1 multi", false);
}{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}}

}


};

gdjs.Game_32Over_32multiCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32Over_32multiCode.GDEnterObjects1.length = 0;
gdjs.Game_32Over_32multiCode.GDEnterObjects2.length = 0;
gdjs.Game_32Over_32multiCode.GDfinObjects1.length = 0;
gdjs.Game_32Over_32multiCode.GDfinObjects2.length = 0;
gdjs.Game_32Over_32multiCode.GDRoBug2Objects1.length = 0;
gdjs.Game_32Over_32multiCode.GDRoBug2Objects2.length = 0;
gdjs.Game_32Over_32multiCode.GDPlayer2Objects1.length = 0;
gdjs.Game_32Over_32multiCode.GDPlayer2Objects2.length = 0;
gdjs.Game_32Over_32multiCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.Game_32Over_32multiCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.Game_32Over_32multiCode.GDNewObjectObjects1.length = 0;
gdjs.Game_32Over_32multiCode.GDNewObjectObjects2.length = 0;
gdjs.Game_32Over_32multiCode.GDNewObject2Objects1.length = 0;
gdjs.Game_32Over_32multiCode.GDNewObject2Objects2.length = 0;
gdjs.Game_32Over_32multiCode.GDNewObject3Objects1.length = 0;
gdjs.Game_32Over_32multiCode.GDNewObject3Objects2.length = 0;
gdjs.Game_32Over_32multiCode.GDNewObject4Objects1.length = 0;
gdjs.Game_32Over_32multiCode.GDNewObject4Objects2.length = 0;

gdjs.Game_32Over_32multiCode.eventsList0(runtimeScene);

return;

}

gdjs['Game_32Over_32multiCode'] = gdjs.Game_32Over_32multiCode;
