gdjs._49_454_32begin_32sceneCode = {};
gdjs._49_454_32begin_32sceneCode.GDEnterObjects1= [];
gdjs._49_454_32begin_32sceneCode.GDEnterObjects2= [];
gdjs._49_454_32begin_32sceneCode.GDfinObjects1= [];
gdjs._49_454_32begin_32sceneCode.GDfinObjects2= [];
gdjs._49_454_32begin_32sceneCode.GDRoBug2Objects1= [];
gdjs._49_454_32begin_32sceneCode.GDRoBug2Objects2= [];
gdjs._49_454_32begin_32sceneCode.GDPlayer2Objects1= [];
gdjs._49_454_32begin_32sceneCode.GDPlayer2Objects2= [];
gdjs._49_454_32begin_32sceneCode.GDPlayer2HitBoxObjects1= [];
gdjs._49_454_32begin_32sceneCode.GDPlayer2HitBoxObjects2= [];
gdjs._49_454_32begin_32sceneCode.GDNewObjectObjects1= [];
gdjs._49_454_32begin_32sceneCode.GDNewObjectObjects2= [];
gdjs._49_454_32begin_32sceneCode.GDNewObject2Objects1= [];
gdjs._49_454_32begin_32sceneCode.GDNewObject2Objects2= [];

gdjs._49_454_32begin_32sceneCode.conditionTrue_0 = {val:false};
gdjs._49_454_32begin_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs._49_454_32begin_32sceneCode.condition1IsTrue_0 = {val:false};


gdjs._49_454_32begin_32sceneCode.eventsList0 = function(runtimeScene) {

{


gdjs._49_454_32begin_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs._49_454_32begin_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs._49_454_32begin_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1-2", false);
}}

}


};

gdjs._49_454_32begin_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49_454_32begin_32sceneCode.GDEnterObjects1.length = 0;
gdjs._49_454_32begin_32sceneCode.GDEnterObjects2.length = 0;
gdjs._49_454_32begin_32sceneCode.GDfinObjects1.length = 0;
gdjs._49_454_32begin_32sceneCode.GDfinObjects2.length = 0;
gdjs._49_454_32begin_32sceneCode.GDRoBug2Objects1.length = 0;
gdjs._49_454_32begin_32sceneCode.GDRoBug2Objects2.length = 0;
gdjs._49_454_32begin_32sceneCode.GDPlayer2Objects1.length = 0;
gdjs._49_454_32begin_32sceneCode.GDPlayer2Objects2.length = 0;
gdjs._49_454_32begin_32sceneCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs._49_454_32begin_32sceneCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs._49_454_32begin_32sceneCode.GDNewObjectObjects1.length = 0;
gdjs._49_454_32begin_32sceneCode.GDNewObjectObjects2.length = 0;
gdjs._49_454_32begin_32sceneCode.GDNewObject2Objects1.length = 0;
gdjs._49_454_32begin_32sceneCode.GDNewObject2Objects2.length = 0;

gdjs._49_454_32begin_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['_49_454_32begin_32sceneCode'] = gdjs._49_454_32begin_32sceneCode;
