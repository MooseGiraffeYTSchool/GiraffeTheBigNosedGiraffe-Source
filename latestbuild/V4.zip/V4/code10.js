gdjs.SettingsCode = {};
gdjs.SettingsCode.GDEnterObjects1= [];
gdjs.SettingsCode.GDEnterObjects2= [];
gdjs.SettingsCode.GDfinObjects1= [];
gdjs.SettingsCode.GDfinObjects2= [];
gdjs.SettingsCode.GDRoBug2Objects1= [];
gdjs.SettingsCode.GDRoBug2Objects2= [];
gdjs.SettingsCode.GDPlayer2Objects1= [];
gdjs.SettingsCode.GDPlayer2Objects2= [];
gdjs.SettingsCode.GDPlayer2HitBoxObjects1= [];
gdjs.SettingsCode.GDPlayer2HitBoxObjects2= [];
gdjs.SettingsCode.GDNewObjectObjects1= [];
gdjs.SettingsCode.GDNewObjectObjects2= [];
gdjs.SettingsCode.GDNewObject2Objects1= [];
gdjs.SettingsCode.GDNewObject2Objects2= [];
gdjs.SettingsCode.GDNewObject3Objects1= [];
gdjs.SettingsCode.GDNewObject3Objects2= [];
gdjs.SettingsCode.GDNewObject4Objects1= [];
gdjs.SettingsCode.GDNewObject4Objects2= [];
gdjs.SettingsCode.GDNewObject5Objects1= [];
gdjs.SettingsCode.GDNewObject5Objects2= [];
gdjs.SettingsCode.GDNewObject6Objects1= [];
gdjs.SettingsCode.GDNewObject6Objects2= [];

gdjs.SettingsCode.conditionTrue_0 = {val:false};
gdjs.SettingsCode.condition0IsTrue_0 = {val:false};
gdjs.SettingsCode.condition1IsTrue_0 = {val:false};
gdjs.SettingsCode.condition2IsTrue_0 = {val:false};


gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.SettingsCode.GDNewObjectObjects1});
gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject2Objects1Objects = Hashtable.newFrom({"NewObject2": gdjs.SettingsCode.GDNewObject2Objects1});
gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject3Objects1Objects = Hashtable.newFrom({"NewObject3": gdjs.SettingsCode.GDNewObject3Objects1});
gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject4Objects1Objects = Hashtable.newFrom({"NewObject4": gdjs.SettingsCode.GDNewObject4Objects1});
gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject5Objects1Objects = Hashtable.newFrom({"NewObject5": gdjs.SettingsCode.GDNewObject5Objects1});
gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject6Objects1Objects = Hashtable.newFrom({"NewObject6": gdjs.SettingsCode.GDNewObject6Objects1});
gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject6Objects1Objects = Hashtable.newFrom({"NewObject6": gdjs.SettingsCode.GDNewObject6Objects1});
gdjs.SettingsCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.SettingsCode.GDNewObjectObjects1);

gdjs.SettingsCode.condition0IsTrue_0.val = false;
{
gdjs.SettingsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObjectObjects1Objects, runtimeScene, true, false);
}if (gdjs.SettingsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject2"), gdjs.SettingsCode.GDNewObject2Objects1);

gdjs.SettingsCode.condition0IsTrue_0.val = false;
{
gdjs.SettingsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject2Objects1Objects, runtimeScene, true, false);
}if (gdjs.SettingsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, false, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject3"), gdjs.SettingsCode.GDNewObject3Objects1);

gdjs.SettingsCode.condition0IsTrue_0.val = false;
{
gdjs.SettingsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject3Objects1Objects, runtimeScene, true, false);
}if (gdjs.SettingsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject4"), gdjs.SettingsCode.GDNewObject4Objects1);

gdjs.SettingsCode.condition0IsTrue_0.val = false;
{
gdjs.SettingsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject4Objects1Objects, runtimeScene, true, false);
}if (gdjs.SettingsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Controls", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject5"), gdjs.SettingsCode.GDNewObject5Objects1);

gdjs.SettingsCode.condition0IsTrue_0.val = false;
{
gdjs.SettingsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject5Objects1Objects, runtimeScene, true, false);
}if (gdjs.SettingsCode.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject6"), gdjs.SettingsCode.GDNewObject6Objects1);

gdjs.SettingsCode.condition0IsTrue_0.val = false;
gdjs.SettingsCode.condition1IsTrue_0.val = false;
{
gdjs.SettingsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject6Objects1Objects, runtimeScene, true, false);
}if ( gdjs.SettingsCode.condition0IsTrue_0.val ) {
{
gdjs.SettingsCode.condition1IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}}
if (gdjs.SettingsCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu pc", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject6"), gdjs.SettingsCode.GDNewObject6Objects1);

gdjs.SettingsCode.condition0IsTrue_0.val = false;
gdjs.SettingsCode.condition1IsTrue_0.val = false;
{
gdjs.SettingsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SettingsCode.mapOfGDgdjs_46SettingsCode_46GDNewObject6Objects1Objects, runtimeScene, true, false);
}if ( gdjs.SettingsCode.condition0IsTrue_0.val ) {
{
gdjs.SettingsCode.condition1IsTrue_0.val = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
}}
if (gdjs.SettingsCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu mobile", false);
}}

}


};

gdjs.SettingsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SettingsCode.GDEnterObjects1.length = 0;
gdjs.SettingsCode.GDEnterObjects2.length = 0;
gdjs.SettingsCode.GDfinObjects1.length = 0;
gdjs.SettingsCode.GDfinObjects2.length = 0;
gdjs.SettingsCode.GDRoBug2Objects1.length = 0;
gdjs.SettingsCode.GDRoBug2Objects2.length = 0;
gdjs.SettingsCode.GDPlayer2Objects1.length = 0;
gdjs.SettingsCode.GDPlayer2Objects2.length = 0;
gdjs.SettingsCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.SettingsCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.SettingsCode.GDNewObjectObjects1.length = 0;
gdjs.SettingsCode.GDNewObjectObjects2.length = 0;
gdjs.SettingsCode.GDNewObject2Objects1.length = 0;
gdjs.SettingsCode.GDNewObject2Objects2.length = 0;
gdjs.SettingsCode.GDNewObject3Objects1.length = 0;
gdjs.SettingsCode.GDNewObject3Objects2.length = 0;
gdjs.SettingsCode.GDNewObject4Objects1.length = 0;
gdjs.SettingsCode.GDNewObject4Objects2.length = 0;
gdjs.SettingsCode.GDNewObject5Objects1.length = 0;
gdjs.SettingsCode.GDNewObject5Objects2.length = 0;
gdjs.SettingsCode.GDNewObject6Objects1.length = 0;
gdjs.SettingsCode.GDNewObject6Objects2.length = 0;

gdjs.SettingsCode.eventsList0(runtimeScene);

return;

}

gdjs['SettingsCode'] = gdjs.SettingsCode;
