gdjs.PauseCode = {};
gdjs.PauseCode.GDEnterObjects1= [];
gdjs.PauseCode.GDEnterObjects2= [];
gdjs.PauseCode.GDfinObjects1= [];
gdjs.PauseCode.GDfinObjects2= [];
gdjs.PauseCode.GDRoBug2Objects1= [];
gdjs.PauseCode.GDRoBug2Objects2= [];
gdjs.PauseCode.GDPlayer2Objects1= [];
gdjs.PauseCode.GDPlayer2Objects2= [];
gdjs.PauseCode.GDPlayer2HitBoxObjects1= [];
gdjs.PauseCode.GDPlayer2HitBoxObjects2= [];
gdjs.PauseCode.GDNewObjectObjects1= [];
gdjs.PauseCode.GDNewObjectObjects2= [];
gdjs.PauseCode.GDNewObject2Objects1= [];
gdjs.PauseCode.GDNewObject2Objects2= [];
gdjs.PauseCode.GDNewObject3Objects1= [];
gdjs.PauseCode.GDNewObject3Objects2= [];

gdjs.PauseCode.conditionTrue_0 = {val:false};
gdjs.PauseCode.condition0IsTrue_0 = {val:false};
gdjs.PauseCode.condition1IsTrue_0 = {val:false};
gdjs.PauseCode.condition2IsTrue_0 = {val:false};


gdjs.PauseCode.mapOfGDgdjs_46PauseCode_46GDNewObject2Objects1Objects = Hashtable.newFrom({"NewObject2": gdjs.PauseCode.GDNewObject2Objects1});
gdjs.PauseCode.mapOfGDgdjs_46PauseCode_46GDNewObject3Objects1Objects = Hashtable.newFrom({"NewObject3": gdjs.PauseCode.GDNewObject3Objects1});
gdjs.PauseCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewObject2"), gdjs.PauseCode.GDNewObject2Objects1);

gdjs.PauseCode.condition0IsTrue_0.val = false;
gdjs.PauseCode.condition1IsTrue_0.val = false;
{
gdjs.PauseCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseCode.mapOfGDgdjs_46PauseCode_46GDNewObject2Objects1Objects, runtimeScene, true, false);
}if ( gdjs.PauseCode.condition0IsTrue_0.val ) {
{
gdjs.PauseCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.PauseCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject3"), gdjs.PauseCode.GDNewObject3Objects1);

gdjs.PauseCode.condition0IsTrue_0.val = false;
gdjs.PauseCode.condition1IsTrue_0.val = false;
{
gdjs.PauseCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseCode.mapOfGDgdjs_46PauseCode_46GDNewObject3Objects1Objects, runtimeScene, true, false);
}if ( gdjs.PauseCode.condition0IsTrue_0.val ) {
{
gdjs.PauseCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.PauseCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Main Menu pc");
}}

}


{


gdjs.PauseCode.condition0IsTrue_0.val = false;
{
gdjs.PauseCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.PauseCode.condition0IsTrue_0.val) {
{gdjs.evtTools.window.setWindowTitle(runtimeScene, "Giraffe the Big Nosed Giraffe -- Paused");
}}

}


};

gdjs.PauseCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PauseCode.GDEnterObjects1.length = 0;
gdjs.PauseCode.GDEnterObjects2.length = 0;
gdjs.PauseCode.GDfinObjects1.length = 0;
gdjs.PauseCode.GDfinObjects2.length = 0;
gdjs.PauseCode.GDRoBug2Objects1.length = 0;
gdjs.PauseCode.GDRoBug2Objects2.length = 0;
gdjs.PauseCode.GDPlayer2Objects1.length = 0;
gdjs.PauseCode.GDPlayer2Objects2.length = 0;
gdjs.PauseCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.PauseCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.PauseCode.GDNewObjectObjects1.length = 0;
gdjs.PauseCode.GDNewObjectObjects2.length = 0;
gdjs.PauseCode.GDNewObject2Objects1.length = 0;
gdjs.PauseCode.GDNewObject2Objects2.length = 0;
gdjs.PauseCode.GDNewObject3Objects1.length = 0;
gdjs.PauseCode.GDNewObject3Objects2.length = 0;

gdjs.PauseCode.eventsList0(runtimeScene);

return;

}

gdjs['PauseCode'] = gdjs.PauseCode;
