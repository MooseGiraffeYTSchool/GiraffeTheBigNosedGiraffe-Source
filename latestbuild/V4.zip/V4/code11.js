gdjs.Coming_32SoonCode = {};
gdjs.Coming_32SoonCode.GDEnterObjects1= [];
gdjs.Coming_32SoonCode.GDEnterObjects2= [];
gdjs.Coming_32SoonCode.GDfinObjects1= [];
gdjs.Coming_32SoonCode.GDfinObjects2= [];
gdjs.Coming_32SoonCode.GDRoBug2Objects1= [];
gdjs.Coming_32SoonCode.GDRoBug2Objects2= [];
gdjs.Coming_32SoonCode.GDPlayer2Objects1= [];
gdjs.Coming_32SoonCode.GDPlayer2Objects2= [];
gdjs.Coming_32SoonCode.GDPlayer2HitBoxObjects1= [];
gdjs.Coming_32SoonCode.GDPlayer2HitBoxObjects2= [];
gdjs.Coming_32SoonCode.GDNewObjectObjects1= [];
gdjs.Coming_32SoonCode.GDNewObjectObjects2= [];
gdjs.Coming_32SoonCode.GDNewObject2Objects1= [];
gdjs.Coming_32SoonCode.GDNewObject2Objects2= [];
gdjs.Coming_32SoonCode.GDNewObject3Objects1= [];
gdjs.Coming_32SoonCode.GDNewObject3Objects2= [];
gdjs.Coming_32SoonCode.GDNewObject4Objects1= [];
gdjs.Coming_32SoonCode.GDNewObject4Objects2= [];

gdjs.Coming_32SoonCode.conditionTrue_0 = {val:false};
gdjs.Coming_32SoonCode.condition0IsTrue_0 = {val:false};
gdjs.Coming_32SoonCode.condition1IsTrue_0 = {val:false};


gdjs.Coming_32SoonCode.mapOfGDgdjs_46Coming_9532SoonCode_46GDEnterObjects1Objects = Hashtable.newFrom({"Enter": gdjs.Coming_32SoonCode.GDEnterObjects1});
gdjs.Coming_32SoonCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs.Coming_32SoonCode.GDEnterObjects1);

gdjs.Coming_32SoonCode.condition0IsTrue_0.val = false;
{
gdjs.Coming_32SoonCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Coming_32SoonCode.mapOfGDgdjs_46Coming_9532SoonCode_46GDEnterObjects1Objects, runtimeScene, true, false);
}if (gdjs.Coming_32SoonCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}}

}


{


gdjs.Coming_32SoonCode.condition0IsTrue_0.val = false;
{
gdjs.Coming_32SoonCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.Coming_32SoonCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs.Coming_32SoonCode.GDEnterObjects1);
{for(var i = 0, len = gdjs.Coming_32SoonCode.GDEnterObjects1.length ;i < len;++i) {
    gdjs.Coming_32SoonCode.GDEnterObjects1[i].hide();
}
}}

}


{


gdjs.Coming_32SoonCode.condition0IsTrue_0.val = false;
{
gdjs.Coming_32SoonCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
}if (gdjs.Coming_32SoonCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}}

}


};

gdjs.Coming_32SoonCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Coming_32SoonCode.GDEnterObjects1.length = 0;
gdjs.Coming_32SoonCode.GDEnterObjects2.length = 0;
gdjs.Coming_32SoonCode.GDfinObjects1.length = 0;
gdjs.Coming_32SoonCode.GDfinObjects2.length = 0;
gdjs.Coming_32SoonCode.GDRoBug2Objects1.length = 0;
gdjs.Coming_32SoonCode.GDRoBug2Objects2.length = 0;
gdjs.Coming_32SoonCode.GDPlayer2Objects1.length = 0;
gdjs.Coming_32SoonCode.GDPlayer2Objects2.length = 0;
gdjs.Coming_32SoonCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.Coming_32SoonCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.Coming_32SoonCode.GDNewObjectObjects1.length = 0;
gdjs.Coming_32SoonCode.GDNewObjectObjects2.length = 0;
gdjs.Coming_32SoonCode.GDNewObject2Objects1.length = 0;
gdjs.Coming_32SoonCode.GDNewObject2Objects2.length = 0;
gdjs.Coming_32SoonCode.GDNewObject3Objects1.length = 0;
gdjs.Coming_32SoonCode.GDNewObject3Objects2.length = 0;
gdjs.Coming_32SoonCode.GDNewObject4Objects1.length = 0;
gdjs.Coming_32SoonCode.GDNewObject4Objects2.length = 0;

gdjs.Coming_32SoonCode.eventsList0(runtimeScene);

return;

}

gdjs['Coming_32SoonCode'] = gdjs.Coming_32SoonCode;
