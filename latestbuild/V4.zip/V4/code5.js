gdjs._49_32raceCode = {};
gdjs._49_32raceCode.forEachIndex3 = 0;

gdjs._49_32raceCode.forEachObjects3 = [];

gdjs._49_32raceCode.forEachTemporary3 = null;

gdjs._49_32raceCode.forEachTotalCount3 = 0;

gdjs._49_32raceCode.GDEnterObjects1= [];
gdjs._49_32raceCode.GDEnterObjects2= [];
gdjs._49_32raceCode.GDEnterObjects3= [];
gdjs._49_32raceCode.GDfinObjects1= [];
gdjs._49_32raceCode.GDfinObjects2= [];
gdjs._49_32raceCode.GDfinObjects3= [];
gdjs._49_32raceCode.GDRoBug2Objects1= [];
gdjs._49_32raceCode.GDRoBug2Objects2= [];
gdjs._49_32raceCode.GDRoBug2Objects3= [];
gdjs._49_32raceCode.GDPlayer2Objects1= [];
gdjs._49_32raceCode.GDPlayer2Objects2= [];
gdjs._49_32raceCode.GDPlayer2Objects3= [];
gdjs._49_32raceCode.GDPlayer2HitBoxObjects1= [];
gdjs._49_32raceCode.GDPlayer2HitBoxObjects2= [];
gdjs._49_32raceCode.GDPlayer2HitBoxObjects3= [];
gdjs._49_32raceCode.GDPlayerObjects1= [];
gdjs._49_32raceCode.GDPlayerObjects2= [];
gdjs._49_32raceCode.GDPlayerObjects3= [];
gdjs._49_32raceCode.GDPlatformObjects1= [];
gdjs._49_32raceCode.GDPlatformObjects2= [];
gdjs._49_32raceCode.GDPlatformObjects3= [];
gdjs._49_32raceCode.GDJumpthruObjects1= [];
gdjs._49_32raceCode.GDJumpthruObjects2= [];
gdjs._49_32raceCode.GDJumpthruObjects3= [];
gdjs._49_32raceCode.GDTiledGrassPlatformObjects1= [];
gdjs._49_32raceCode.GDTiledGrassPlatformObjects2= [];
gdjs._49_32raceCode.GDTiledGrassPlatformObjects3= [];
gdjs._49_32raceCode.GDTiledCastlePlatformObjects1= [];
gdjs._49_32raceCode.GDTiledCastlePlatformObjects2= [];
gdjs._49_32raceCode.GDTiledCastlePlatformObjects3= [];
gdjs._49_32raceCode.GDMovingPlatformObjects1= [];
gdjs._49_32raceCode.GDMovingPlatformObjects2= [];
gdjs._49_32raceCode.GDMovingPlatformObjects3= [];
gdjs._49_32raceCode.GDGoLeftObjects1= [];
gdjs._49_32raceCode.GDGoLeftObjects2= [];
gdjs._49_32raceCode.GDGoLeftObjects3= [];
gdjs._49_32raceCode.GDGoRightObjects1= [];
gdjs._49_32raceCode.GDGoRightObjects2= [];
gdjs._49_32raceCode.GDGoRightObjects3= [];
gdjs._49_32raceCode.GDLadderObjects1= [];
gdjs._49_32raceCode.GDLadderObjects2= [];
gdjs._49_32raceCode.GDLadderObjects3= [];
gdjs._49_32raceCode.GDPlayerHitBoxObjects1= [];
gdjs._49_32raceCode.GDPlayerHitBoxObjects2= [];
gdjs._49_32raceCode.GDPlayerHitBoxObjects3= [];
gdjs._49_32raceCode.GDSlimeWalkObjects1= [];
gdjs._49_32raceCode.GDSlimeWalkObjects2= [];
gdjs._49_32raceCode.GDSlimeWalkObjects3= [];
gdjs._49_32raceCode.GDBackgroundObjectsObjects1= [];
gdjs._49_32raceCode.GDBackgroundObjectsObjects2= [];
gdjs._49_32raceCode.GDBackgroundObjectsObjects3= [];
gdjs._49_32raceCode.GDScoreObjects1= [];
gdjs._49_32raceCode.GDScoreObjects2= [];
gdjs._49_32raceCode.GDScoreObjects3= [];
gdjs._49_32raceCode.GDCoin2Objects1= [];
gdjs._49_32raceCode.GDCoin2Objects2= [];
gdjs._49_32raceCode.GDCoin2Objects3= [];
gdjs._49_32raceCode.GDCoinObjects1= [];
gdjs._49_32raceCode.GDCoinObjects2= [];
gdjs._49_32raceCode.GDCoinObjects3= [];
gdjs._49_32raceCode.GDCoinIconObjects1= [];
gdjs._49_32raceCode.GDCoinIconObjects2= [];
gdjs._49_32raceCode.GDCoinIconObjects3= [];
gdjs._49_32raceCode.GDLeftButtonObjects1= [];
gdjs._49_32raceCode.GDLeftButtonObjects2= [];
gdjs._49_32raceCode.GDLeftButtonObjects3= [];
gdjs._49_32raceCode.GDRightButtonObjects1= [];
gdjs._49_32raceCode.GDRightButtonObjects2= [];
gdjs._49_32raceCode.GDRightButtonObjects3= [];
gdjs._49_32raceCode.GDJumpButtonObjects1= [];
gdjs._49_32raceCode.GDJumpButtonObjects2= [];
gdjs._49_32raceCode.GDJumpButtonObjects3= [];
gdjs._49_32raceCode.GDArrowButtonsBgObjects1= [];
gdjs._49_32raceCode.GDArrowButtonsBgObjects2= [];
gdjs._49_32raceCode.GDArrowButtonsBgObjects3= [];
gdjs._49_32raceCode.GDTiledForestBackgroundObjects1= [];
gdjs._49_32raceCode.GDTiledForestBackgroundObjects2= [];
gdjs._49_32raceCode.GDTiledForestBackgroundObjects3= [];
gdjs._49_32raceCode.GDCheckpointObjects1= [];
gdjs._49_32raceCode.GDCheckpointObjects2= [];
gdjs._49_32raceCode.GDCheckpointObjects3= [];
gdjs._49_32raceCode.GDTopButtonObjects1= [];
gdjs._49_32raceCode.GDTopButtonObjects2= [];
gdjs._49_32raceCode.GDTopButtonObjects3= [];
gdjs._49_32raceCode.GDBottomButtonObjects1= [];
gdjs._49_32raceCode.GDBottomButtonObjects2= [];
gdjs._49_32raceCode.GDBottomButtonObjects3= [];
gdjs._49_32raceCode.GDFadeInObjects1= [];
gdjs._49_32raceCode.GDFadeInObjects2= [];
gdjs._49_32raceCode.GDFadeInObjects3= [];
gdjs._49_32raceCode.GDNewObjectObjects1= [];
gdjs._49_32raceCode.GDNewObjectObjects2= [];
gdjs._49_32raceCode.GDNewObjectObjects3= [];
gdjs._49_32raceCode.GDTEXTObjects1= [];
gdjs._49_32raceCode.GDTEXTObjects2= [];
gdjs._49_32raceCode.GDTEXTObjects3= [];
gdjs._49_32raceCode.GDNewObject2Objects1= [];
gdjs._49_32raceCode.GDNewObject2Objects2= [];
gdjs._49_32raceCode.GDNewObject2Objects3= [];

gdjs._49_32raceCode.conditionTrue_0 = {val:false};
gdjs._49_32raceCode.condition0IsTrue_0 = {val:false};
gdjs._49_32raceCode.condition1IsTrue_0 = {val:false};
gdjs._49_32raceCode.condition2IsTrue_0 = {val:false};
gdjs._49_32raceCode.conditionTrue_1 = {val:false};
gdjs._49_32raceCode.condition0IsTrue_1 = {val:false};
gdjs._49_32raceCode.condition1IsTrue_1 = {val:false};
gdjs._49_32raceCode.condition2IsTrue_1 = {val:false};


gdjs._49_32raceCode.eventsList0 = function(runtimeScene) {

{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
{gdjs._49_32raceCode.conditionTrue_1 = gdjs._49_32raceCode.condition0IsTrue_0;
gdjs._49_32raceCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17334284);
}
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}}

}


};gdjs._49_32raceCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs._49_32raceCode.GDPlayerHitBoxObjects1, gdjs._49_32raceCode.GDPlayerHitBoxObjects2);


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( !(gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDPlayerHitBoxObjects2[k] = gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerObjects2[i].setAnimationName("Idle");
}
}}

}


{

/* Reuse gdjs._49_32raceCode.GDPlayerHitBoxObjects1 */

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDPlayerHitBoxObjects1[k] = gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerObjects1[i].setAnimationName("Running");
}
}}

}


};gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDGoLeftObjects1Objects = Hashtable.newFrom({"GoLeft": gdjs._49_32raceCode.GDGoLeftObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs._49_32raceCode.GDMovingPlatformObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDGoRightObjects1Objects = Hashtable.newFrom({"GoRight": gdjs._49_32raceCode.GDGoRightObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs._49_32raceCode.GDMovingPlatformObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDGoLeftObjects2Objects = Hashtable.newFrom({"GoLeft": gdjs._49_32raceCode.GDGoLeftObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDSlimeWalkObjects2Objects = Hashtable.newFrom({"SlimeWalk": gdjs._49_32raceCode.GDSlimeWalkObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDGoRightObjects2Objects = Hashtable.newFrom({"GoRight": gdjs._49_32raceCode.GDGoRightObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDSlimeWalkObjects2Objects = Hashtable.newFrom({"SlimeWalk": gdjs._49_32raceCode.GDSlimeWalkObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs._49_32raceCode.GDPlayerHitBoxObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDSlimeWalkObjects1Objects = Hashtable.newFrom({"SlimeWalk": gdjs._49_32raceCode.GDSlimeWalkObjects1});
gdjs._49_32raceCode.eventsList2 = function(runtimeScene) {

};gdjs._49_32raceCode.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs._49_32raceCode.GDSlimeWalkObjects2 */

for(gdjs._49_32raceCode.forEachIndex3 = 0;gdjs._49_32raceCode.forEachIndex3 < gdjs._49_32raceCode.GDSlimeWalkObjects2.length;++gdjs._49_32raceCode.forEachIndex3) {
gdjs._49_32raceCode.GDSlimeWalkObjects3.length = 0;


gdjs._49_32raceCode.forEachTemporary3 = gdjs._49_32raceCode.GDSlimeWalkObjects2[gdjs._49_32raceCode.forEachIndex3];
gdjs._49_32raceCode.GDSlimeWalkObjects3.push(gdjs._49_32raceCode.forEachTemporary3);
if (true) {
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}
}

}


};gdjs._49_32raceCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs._49_32raceCode.GDPlayerHitBoxObjects1, gdjs._49_32raceCode.GDPlayerHitBoxObjects2);


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDPlayerHitBoxObjects2[k] = gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDPlayerHitBoxObjects2 */
gdjs.copyArray(gdjs._49_32raceCode.GDSlimeWalkObjects1, gdjs._49_32raceCode.GDSlimeWalkObjects2);

{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects2[i].activateBehavior("PlatformerObject", true);
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").setGravity(1500);
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}
{ //Subevents
gdjs._49_32raceCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs._49_32raceCode.GDPlayerHitBoxObjects1 */

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( !(gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDPlayerHitBoxObjects1[k] = gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


};gdjs._49_32raceCode.eventsList5 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs._49_32raceCode.GDGoLeftObjects2);
gdjs.copyArray(gdjs._49_32raceCode.GDSlimeWalkObjects1, gdjs._49_32raceCode.GDSlimeWalkObjects2);


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDGoLeftObjects2Objects, gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDSlimeWalkObjects2Objects, false, runtimeScene, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects2[i].returnVariable(gdjs._49_32raceCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")).setNumber(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs._49_32raceCode.GDGoRightObjects2);
gdjs.copyArray(gdjs._49_32raceCode.GDSlimeWalkObjects1, gdjs._49_32raceCode.GDSlimeWalkObjects2);


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDGoRightObjects2Objects, gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDSlimeWalkObjects2Objects, false, runtimeScene, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects2[i].returnVariable(gdjs._49_32raceCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs._49_32raceCode.GDSlimeWalkObjects1, gdjs._49_32raceCode.GDSlimeWalkObjects2);


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs._49_32raceCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDSlimeWalkObjects2[k] = gdjs._49_32raceCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDSlimeWalkObjects2.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(gdjs._49_32raceCode.GDSlimeWalkObjects1, gdjs._49_32raceCode.GDSlimeWalkObjects2);


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs._49_32raceCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDSlimeWalkObjects2[k] = gdjs._49_32raceCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDSlimeWalkObjects2.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects2[i].flipX(true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);
/* Reuse gdjs._49_32raceCode.GDSlimeWalkObjects1 */

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlayerHitBoxObjects1Objects, gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDSlimeWalkObjects1Objects, false, runtimeScene, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs._49_32raceCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs._49_32raceCode.GDPlayerHitBoxObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs._49_32raceCode.GDCoinObjects1});
gdjs._49_32raceCode.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs._49_32raceCode.GDScoreObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDScoreObjects1[i].setString("x " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


};gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDLeftButtonObjects2Objects = Hashtable.newFrom({"LeftButton": gdjs._49_32raceCode.GDLeftButtonObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDRightButtonObjects2Objects = Hashtable.newFrom({"RightButton": gdjs._49_32raceCode.GDRightButtonObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDTopButtonObjects2Objects = Hashtable.newFrom({"TopButton": gdjs._49_32raceCode.GDTopButtonObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDBottomButtonObjects2Objects = Hashtable.newFrom({"BottomButton": gdjs._49_32raceCode.GDBottomButtonObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDJumpButtonObjects1Objects = Hashtable.newFrom({"JumpButton": gdjs._49_32raceCode.GDJumpButtonObjects1});
gdjs._49_32raceCode.eventsList7 = function(runtimeScene) {

{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ArrowButtonsBg"), gdjs._49_32raceCode.GDArrowButtonsBgObjects2);
gdjs.copyArray(runtimeScene.getObjects("BottomButton"), gdjs._49_32raceCode.GDBottomButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs._49_32raceCode.GDJumpButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs._49_32raceCode.GDLeftButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs._49_32raceCode.GDRightButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs._49_32raceCode.GDTopButtonObjects2);
{for(var i = 0, len = gdjs._49_32raceCode.GDLeftButtonObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDLeftButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_32raceCode.GDRightButtonObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDRightButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_32raceCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDJumpButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_32raceCode.GDArrowButtonsBgObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDArrowButtonsBgObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_32raceCode.GDTopButtonObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDTopButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs._49_32raceCode.GDBottomButtonObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDBottomButtonObjects2[i].hide();
}
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs._49_32raceCode.GDLeftButtonObjects2);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDLeftButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs._49_32raceCode.GDRightButtonObjects2);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDRightButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs._49_32raceCode.GDTopButtonObjects2);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDTopButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateUpKey();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateLadderKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BottomButton"), gdjs._49_32raceCode.GDBottomButtonObjects2);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDBottomButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateDownKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs._49_32raceCode.GDJumpButtonObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDJumpButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlayerHitBoxObjects2Objects = Hashtable.newFrom({"PlayerHitBox": gdjs._49_32raceCode.GDPlayerHitBoxObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs._49_32raceCode.GDCheckpointObjects2});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDFadeInObjects2Objects = Hashtable.newFrom({"FadeIn": gdjs._49_32raceCode.GDFadeInObjects2});
gdjs._49_32raceCode.eventsList8 = function(runtimeScene) {

{



}


{


{
gdjs._49_32raceCode.GDFadeInObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDFadeInObjects2Objects, 0, 0, "GUI");
}{for(var i = 0, len = gdjs._49_32raceCode.GDFadeInObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDFadeInObjects2[i].setWidth(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene));
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDFadeInObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDFadeInObjects2[i].setHeight(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene));
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDFadeInObjects2.length ;i < len;++i) {
    gdjs._49_32raceCode.GDFadeInObjects2[i].getBehavior("Tween").addObjectOpacityTween("FadeIn", 0, "easeInQuad", 1500, true);
}
}}

}


};gdjs._49_32raceCode.eventsList9 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs._49_32raceCode.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects2);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
gdjs._49_32raceCode.condition1IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlayerHitBoxObjects2Objects, gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDCheckpointObjects2Objects, false, runtimeScene, false);
}if ( gdjs._49_32raceCode.condition0IsTrue_0.val ) {
{
{gdjs._49_32raceCode.conditionTrue_1 = gdjs._49_32raceCode.condition1IsTrue_0;
gdjs._49_32raceCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17353436);
}
}}
if (gdjs._49_32raceCode.condition1IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDCheckpointObjects2 */
{runtimeScene.getVariables().getFromIndex(1).setNumber((( gdjs._49_32raceCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs._49_32raceCode.GDCheckpointObjects2[0].getPointX("")));
}{runtimeScene.getVariables().getFromIndex(2).setNumber((( gdjs._49_32raceCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs._49_32raceCode.GDCheckpointObjects2[0].getPointY("")));
}}

}


{



}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 1;
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "life lost sound.wav", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Over", true);
}
{ //Subevents
gdjs._49_32raceCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects2);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i].getY() > 1000 ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDPlayerHitBoxObjects2[k] = gdjs._49_32raceCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


{



}


};gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDfinObjects1Objects = Hashtable.newFrom({"fin": gdjs._49_32raceCode.GDfinObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs._49_32raceCode.GDPlayerObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDCoinIconObjects1Objects = Hashtable.newFrom({"CoinIcon": gdjs._49_32raceCode.GDCoinIconObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlatformObjects1Objects = Hashtable.newFrom({"Platform": gdjs._49_32raceCode.GDPlatformObjects1});
gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDNewObject2Objects1Objects = Hashtable.newFrom({"NewObject2": gdjs._49_32raceCode.GDNewObject2Objects1});
gdjs._49_32raceCode.eventsList10 = function(runtimeScene) {

{


{
}

}


};gdjs._49_32raceCode.eventsList11 = function(runtimeScene) {

{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerObjects1[i].setPosition((( gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs._49_32raceCode.GDPlayerHitBoxObjects1[0].getPointX("")) - 12,(( gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs._49_32raceCode.GDPlayerHitBoxObjects1[0].getPointY("")));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDPlayerHitBoxObjects1[k] = gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}
{ //Subevents
gdjs._49_32raceCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDPlayerHitBoxObjects1[k] = gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDPlayerHitBoxObjects1[k] = gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs._49_32raceCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDPlayerHitBoxObjects1[k] = gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerObjects1[i].flipX(true);
}
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerObjects1[i].flipX(false);
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs._49_32raceCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs._49_32raceCode.GDPlayerObjects1[0].getPointX("")), "", 0);
}}

}


{



}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs._49_32raceCode.GDGoLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs._49_32raceCode.GDGoRightObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDGoLeftObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDGoLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDGoRightObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDGoRightObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs._49_32raceCode.GDGoLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform"), gdjs._49_32raceCode.GDMovingPlatformObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDGoLeftObjects1Objects, gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs._49_32raceCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDMovingPlatformObjects1[i].addForce(-(150), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs._49_32raceCode.GDGoRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform"), gdjs._49_32raceCode.GDMovingPlatformObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDGoRightObjects1Objects, gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs._49_32raceCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDMovingPlatformObjects1[i].addForce(150, 0, 1);
}
}}

}


{



}


{



}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SlimeWalk"), gdjs._49_32raceCode.GDSlimeWalkObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs._49_32raceCode.GDSlimeWalkObjects1[i].isCurrentAnimationName("Dead")) ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDSlimeWalkObjects1[k] = gdjs._49_32raceCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDSlimeWalkObjects1.length = k;}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs._49_32raceCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SlimeWalk"), gdjs._49_32raceCode.GDSlimeWalkObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
gdjs._49_32raceCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDSlimeWalkObjects1[i].isCurrentAnimationName("Dead") ) {
        gdjs._49_32raceCode.condition0IsTrue_0.val = true;
        gdjs._49_32raceCode.GDSlimeWalkObjects1[k] = gdjs._49_32raceCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDSlimeWalkObjects1.length = k;}if ( gdjs._49_32raceCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs._49_32raceCode.GDSlimeWalkObjects1[i].getBehavior("Tween").isPlaying("FadeOut")) ) {
        gdjs._49_32raceCode.condition1IsTrue_0.val = true;
        gdjs._49_32raceCode.GDSlimeWalkObjects1[k] = gdjs._49_32raceCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDSlimeWalkObjects1.length = k;}}
if (gdjs._49_32raceCode.condition1IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDSlimeWalkObjects1 */
{for(var i = 0, len = gdjs._49_32raceCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDSlimeWalkObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeOutQuad", 1500, true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs._49_32raceCode.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
gdjs._49_32raceCode.condition1IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlayerHitBoxObjects1Objects, gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDCoinObjects1Objects, false, runtimeScene, false);
}if ( gdjs._49_32raceCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._49_32raceCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs._49_32raceCode.GDCoinObjects1[i].getOpacity() == 255 ) {
        gdjs._49_32raceCode.condition1IsTrue_0.val = true;
        gdjs._49_32raceCode.GDCoinObjects1[k] = gdjs._49_32raceCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs._49_32raceCode.GDCoinObjects1.length = k;}}
if (gdjs._49_32raceCode.condition1IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDCoinObjects1 */
{for(var i = 0, len = gdjs._49_32raceCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDCoinObjects1[i].setOpacity(254);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs._49_32raceCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDCoinObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeInQuad", 700, true);
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDCoinObjects1[i].getBehavior("Tween").addObjectPositionYTween("MoveUp", (gdjs._49_32raceCode.GDCoinObjects1[i].getPointY("")) - 50, "easeOutQuad", 700, false);
}
}}

}


{


gdjs._49_32raceCode.eventsList6(runtimeScene);
}


{


gdjs._49_32raceCode.eventsList7(runtimeScene);
}


{


gdjs._49_32raceCode.eventsList9(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs._49_32raceCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("fin"), gdjs._49_32raceCode.GDfinObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDfinObjects1Objects, gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1-2 begin scene", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CoinIcon"), gdjs._49_32raceCode.GDCoinIconObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
gdjs._49_32raceCode.condition1IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDCoinIconObjects1Objects, runtimeScene, true, false);
}if ( gdjs._49_32raceCode.condition0IsTrue_0.val ) {
{
gdjs._49_32raceCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs._49_32raceCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Pause");
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "LEFT", "LEFT", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "LEFT", "RIGHT", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "LEFT", "UP", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateUpKey();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateLadderKey();
}
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Button_released.func(runtimeScene, 1, "CROSS", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs._49_32raceCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Controller_type.func(runtimeScene, 1, "PS4", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TEXT"), gdjs._49_32raceCode.GDTEXTObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDTEXTObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDTEXTObjects1[i].hide(false);
}
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TEXT"), gdjs._49_32raceCode.GDTEXTObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDTEXTObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDTEXTObjects1[i].hide();
}
}}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = !(gdjs.evtsExt__Gamepads__C_Controller_X_is_connected.func(runtimeScene, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TEXT"), gdjs._49_32raceCode.GDTEXTObjects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDTEXTObjects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDTEXTObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject2"), gdjs._49_32raceCode.GDNewObject2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs._49_32raceCode.GDPlatformObjects1);

gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDPlatformObjects1Objects, gdjs._49_32raceCode.mapOfGDgdjs_46_9549_9532raceCode_46GDNewObject2Objects1Objects, false, runtimeScene, false);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
/* Reuse gdjs._49_32raceCode.GDNewObject2Objects1 */
{for(var i = 0, len = gdjs._49_32raceCode.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDNewObject2Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDNewObject2Objects1[i].getBehavior("PlatformerObject").simulateUpKey();
}
}{for(var i = 0, len = gdjs._49_32raceCode.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDNewObject2Objects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
{ //Subevents
gdjs._49_32raceCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


gdjs._49_32raceCode.condition0IsTrue_0.val = false;
{
gdjs._49_32raceCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49_32raceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject2"), gdjs._49_32raceCode.GDNewObject2Objects1);
{for(var i = 0, len = gdjs._49_32raceCode.GDNewObject2Objects1.length ;i < len;++i) {
    gdjs._49_32raceCode.GDNewObject2Objects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


};

gdjs._49_32raceCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49_32raceCode.GDEnterObjects1.length = 0;
gdjs._49_32raceCode.GDEnterObjects2.length = 0;
gdjs._49_32raceCode.GDEnterObjects3.length = 0;
gdjs._49_32raceCode.GDfinObjects1.length = 0;
gdjs._49_32raceCode.GDfinObjects2.length = 0;
gdjs._49_32raceCode.GDfinObjects3.length = 0;
gdjs._49_32raceCode.GDRoBug2Objects1.length = 0;
gdjs._49_32raceCode.GDRoBug2Objects2.length = 0;
gdjs._49_32raceCode.GDRoBug2Objects3.length = 0;
gdjs._49_32raceCode.GDPlayer2Objects1.length = 0;
gdjs._49_32raceCode.GDPlayer2Objects2.length = 0;
gdjs._49_32raceCode.GDPlayer2Objects3.length = 0;
gdjs._49_32raceCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs._49_32raceCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs._49_32raceCode.GDPlayer2HitBoxObjects3.length = 0;
gdjs._49_32raceCode.GDPlayerObjects1.length = 0;
gdjs._49_32raceCode.GDPlayerObjects2.length = 0;
gdjs._49_32raceCode.GDPlayerObjects3.length = 0;
gdjs._49_32raceCode.GDPlatformObjects1.length = 0;
gdjs._49_32raceCode.GDPlatformObjects2.length = 0;
gdjs._49_32raceCode.GDPlatformObjects3.length = 0;
gdjs._49_32raceCode.GDJumpthruObjects1.length = 0;
gdjs._49_32raceCode.GDJumpthruObjects2.length = 0;
gdjs._49_32raceCode.GDJumpthruObjects3.length = 0;
gdjs._49_32raceCode.GDTiledGrassPlatformObjects1.length = 0;
gdjs._49_32raceCode.GDTiledGrassPlatformObjects2.length = 0;
gdjs._49_32raceCode.GDTiledGrassPlatformObjects3.length = 0;
gdjs._49_32raceCode.GDTiledCastlePlatformObjects1.length = 0;
gdjs._49_32raceCode.GDTiledCastlePlatformObjects2.length = 0;
gdjs._49_32raceCode.GDTiledCastlePlatformObjects3.length = 0;
gdjs._49_32raceCode.GDMovingPlatformObjects1.length = 0;
gdjs._49_32raceCode.GDMovingPlatformObjects2.length = 0;
gdjs._49_32raceCode.GDMovingPlatformObjects3.length = 0;
gdjs._49_32raceCode.GDGoLeftObjects1.length = 0;
gdjs._49_32raceCode.GDGoLeftObjects2.length = 0;
gdjs._49_32raceCode.GDGoLeftObjects3.length = 0;
gdjs._49_32raceCode.GDGoRightObjects1.length = 0;
gdjs._49_32raceCode.GDGoRightObjects2.length = 0;
gdjs._49_32raceCode.GDGoRightObjects3.length = 0;
gdjs._49_32raceCode.GDLadderObjects1.length = 0;
gdjs._49_32raceCode.GDLadderObjects2.length = 0;
gdjs._49_32raceCode.GDLadderObjects3.length = 0;
gdjs._49_32raceCode.GDPlayerHitBoxObjects1.length = 0;
gdjs._49_32raceCode.GDPlayerHitBoxObjects2.length = 0;
gdjs._49_32raceCode.GDPlayerHitBoxObjects3.length = 0;
gdjs._49_32raceCode.GDSlimeWalkObjects1.length = 0;
gdjs._49_32raceCode.GDSlimeWalkObjects2.length = 0;
gdjs._49_32raceCode.GDSlimeWalkObjects3.length = 0;
gdjs._49_32raceCode.GDBackgroundObjectsObjects1.length = 0;
gdjs._49_32raceCode.GDBackgroundObjectsObjects2.length = 0;
gdjs._49_32raceCode.GDBackgroundObjectsObjects3.length = 0;
gdjs._49_32raceCode.GDScoreObjects1.length = 0;
gdjs._49_32raceCode.GDScoreObjects2.length = 0;
gdjs._49_32raceCode.GDScoreObjects3.length = 0;
gdjs._49_32raceCode.GDCoin2Objects1.length = 0;
gdjs._49_32raceCode.GDCoin2Objects2.length = 0;
gdjs._49_32raceCode.GDCoin2Objects3.length = 0;
gdjs._49_32raceCode.GDCoinObjects1.length = 0;
gdjs._49_32raceCode.GDCoinObjects2.length = 0;
gdjs._49_32raceCode.GDCoinObjects3.length = 0;
gdjs._49_32raceCode.GDCoinIconObjects1.length = 0;
gdjs._49_32raceCode.GDCoinIconObjects2.length = 0;
gdjs._49_32raceCode.GDCoinIconObjects3.length = 0;
gdjs._49_32raceCode.GDLeftButtonObjects1.length = 0;
gdjs._49_32raceCode.GDLeftButtonObjects2.length = 0;
gdjs._49_32raceCode.GDLeftButtonObjects3.length = 0;
gdjs._49_32raceCode.GDRightButtonObjects1.length = 0;
gdjs._49_32raceCode.GDRightButtonObjects2.length = 0;
gdjs._49_32raceCode.GDRightButtonObjects3.length = 0;
gdjs._49_32raceCode.GDJumpButtonObjects1.length = 0;
gdjs._49_32raceCode.GDJumpButtonObjects2.length = 0;
gdjs._49_32raceCode.GDJumpButtonObjects3.length = 0;
gdjs._49_32raceCode.GDArrowButtonsBgObjects1.length = 0;
gdjs._49_32raceCode.GDArrowButtonsBgObjects2.length = 0;
gdjs._49_32raceCode.GDArrowButtonsBgObjects3.length = 0;
gdjs._49_32raceCode.GDTiledForestBackgroundObjects1.length = 0;
gdjs._49_32raceCode.GDTiledForestBackgroundObjects2.length = 0;
gdjs._49_32raceCode.GDTiledForestBackgroundObjects3.length = 0;
gdjs._49_32raceCode.GDCheckpointObjects1.length = 0;
gdjs._49_32raceCode.GDCheckpointObjects2.length = 0;
gdjs._49_32raceCode.GDCheckpointObjects3.length = 0;
gdjs._49_32raceCode.GDTopButtonObjects1.length = 0;
gdjs._49_32raceCode.GDTopButtonObjects2.length = 0;
gdjs._49_32raceCode.GDTopButtonObjects3.length = 0;
gdjs._49_32raceCode.GDBottomButtonObjects1.length = 0;
gdjs._49_32raceCode.GDBottomButtonObjects2.length = 0;
gdjs._49_32raceCode.GDBottomButtonObjects3.length = 0;
gdjs._49_32raceCode.GDFadeInObjects1.length = 0;
gdjs._49_32raceCode.GDFadeInObjects2.length = 0;
gdjs._49_32raceCode.GDFadeInObjects3.length = 0;
gdjs._49_32raceCode.GDNewObjectObjects1.length = 0;
gdjs._49_32raceCode.GDNewObjectObjects2.length = 0;
gdjs._49_32raceCode.GDNewObjectObjects3.length = 0;
gdjs._49_32raceCode.GDTEXTObjects1.length = 0;
gdjs._49_32raceCode.GDTEXTObjects2.length = 0;
gdjs._49_32raceCode.GDTEXTObjects3.length = 0;
gdjs._49_32raceCode.GDNewObject2Objects1.length = 0;
gdjs._49_32raceCode.GDNewObject2Objects2.length = 0;
gdjs._49_32raceCode.GDNewObject2Objects3.length = 0;

gdjs._49_32raceCode.eventsList11(runtimeScene);

return;

}

gdjs['_49_32raceCode'] = gdjs._49_32raceCode;
