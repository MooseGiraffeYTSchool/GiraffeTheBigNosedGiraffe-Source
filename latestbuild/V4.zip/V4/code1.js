gdjs.Main_32Menu_32mobileCode = {};
gdjs.Main_32Menu_32mobileCode.GDEnterObjects1= [];
gdjs.Main_32Menu_32mobileCode.GDEnterObjects2= [];
gdjs.Main_32Menu_32mobileCode.GDfinObjects1= [];
gdjs.Main_32Menu_32mobileCode.GDfinObjects2= [];
gdjs.Main_32Menu_32mobileCode.GDRoBug2Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDRoBug2Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDPlayer2Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDPlayer2Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDPlayer2HitBoxObjects1= [];
gdjs.Main_32Menu_32mobileCode.GDPlayer2HitBoxObjects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject2Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject2Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject3Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject3Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObjectObjects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObjectObjects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject4Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject4Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject6Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject6Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject7Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject7Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject8Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject8Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject9Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject9Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDStPRITZXObjects1= [];
gdjs.Main_32Menu_32mobileCode.GDStPRITZXObjects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject10Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject10Objects2= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects1= [];
gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects2= [];

gdjs.Main_32Menu_32mobileCode.conditionTrue_0 = {val:false};
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0 = {val:false};
gdjs.Main_32Menu_32mobileCode.condition1IsTrue_0 = {val:false};


gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.Main_32Menu_32mobileCode.GDNewObjectObjects1});
gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObject4Objects1Objects = Hashtable.newFrom({"NewObject4": gdjs.Main_32Menu_32mobileCode.GDNewObject4Objects1});
gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObject6Objects1Objects = Hashtable.newFrom({"NewObject6": gdjs.Main_32Menu_32mobileCode.GDNewObject6Objects1});
gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObject7Objects1Objects = Hashtable.newFrom({"NewObject7": gdjs.Main_32Menu_32mobileCode.GDNewObject7Objects1});
gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObject10Objects1Objects = Hashtable.newFrom({"NewObject10": gdjs.Main_32Menu_32mobileCode.GDNewObject10Objects1});
gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDStPRITZXObjects1Objects = Hashtable.newFrom({"StPRITZX": gdjs.Main_32Menu_32mobileCode.GDStPRITZXObjects1});
gdjs.Main_32Menu_32mobileCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.Main_32Menu_32mobileCode.GDNewObjectObjects1);

gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObjectObjects1Objects, runtimeScene, true, false);
}if (gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "w", false);
}}

}


{


gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject11"), gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects1);
{for(var i = 0, len = gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject4"), gdjs.Main_32Menu_32mobileCode.GDNewObject4Objects1);

gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObject4Objects1Objects, runtimeScene, true, false);
}if (gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}}

}


{


gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Controller_X_is_connected.func(runtimeScene, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject5"), gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects1);
{for(var i = 0, len = gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects1[i].hide(false);
}
}}

}


{


gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject5"), gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects1);
{for(var i = 0, len = gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject6"), gdjs.Main_32Menu_32mobileCode.GDNewObject6Objects1);

gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObject6Objects1Objects, runtimeScene, true, false);
}if (gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Mods", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject7"), gdjs.Main_32Menu_32mobileCode.GDNewObject7Objects1);

gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObject7Objects1Objects, runtimeScene, true, false);
}if (gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject11"), gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects1);
/* Reuse gdjs.Main_32Menu_32mobileCode.GDNewObject7Objects1 */
{gdjs.evtTools.sound.preloadMusic(runtimeScene, "zoonitesong.mp3");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "gameOver.ogg");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "gameOverEnd.ogg");
}{for(var i = 0, len = gdjs.Main_32Menu_32mobileCode.GDNewObject7Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32mobileCode.GDNewObject7Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects1.length ;i < len;++i) {
    gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects1[i].hide(false);
}
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "26 - Robotnik.mp3");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject10"), gdjs.Main_32Menu_32mobileCode.GDNewObject10Objects1);

gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDNewObject10Objects1Objects, runtimeScene, true, false);
}if (gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Inst.ogg", 2, false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("StPRITZX"), gdjs.Main_32Menu_32mobileCode.GDStPRITZXObjects1);

gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32Menu_32mobileCode.mapOfGDgdjs_46Main_9532Menu_9532mobileCode_46GDStPRITZXObjects1Objects, runtimeScene, true, false);
}if (gdjs.Main_32Menu_32mobileCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 2);
}}

}


{


{
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "255;159;0");
}}

}


{


{
}

}


};

gdjs.Main_32Menu_32mobileCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32Menu_32mobileCode.GDEnterObjects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDEnterObjects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDfinObjects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDfinObjects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDRoBug2Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDRoBug2Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDPlayer2Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDPlayer2Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject2Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject2Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject3Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject3Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObjectObjects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObjectObjects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject4Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject4Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject5Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject6Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject6Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject7Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject7Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject8Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject8Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject9Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject9Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDStPRITZXObjects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDStPRITZXObjects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject10Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject10Objects2.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects1.length = 0;
gdjs.Main_32Menu_32mobileCode.GDNewObject11Objects2.length = 0;

gdjs.Main_32Menu_32mobileCode.eventsList0(runtimeScene);

return;

}

gdjs['Main_32Menu_32mobileCode'] = gdjs.Main_32Menu_32mobileCode;
