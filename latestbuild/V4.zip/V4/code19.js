gdjs._49_32begin_32scene_32multiCode = {};
gdjs._49_32begin_32scene_32multiCode.GDEnterObjects1= [];
gdjs._49_32begin_32scene_32multiCode.GDEnterObjects2= [];
gdjs._49_32begin_32scene_32multiCode.GDfinObjects1= [];
gdjs._49_32begin_32scene_32multiCode.GDfinObjects2= [];
gdjs._49_32begin_32scene_32multiCode.GDRoBug2Objects1= [];
gdjs._49_32begin_32scene_32multiCode.GDRoBug2Objects2= [];
gdjs._49_32begin_32scene_32multiCode.GDPlayer2Objects1= [];
gdjs._49_32begin_32scene_32multiCode.GDPlayer2Objects2= [];
gdjs._49_32begin_32scene_32multiCode.GDPlayer2HitBoxObjects1= [];
gdjs._49_32begin_32scene_32multiCode.GDPlayer2HitBoxObjects2= [];
gdjs._49_32begin_32scene_32multiCode.GDNewObjectObjects1= [];
gdjs._49_32begin_32scene_32multiCode.GDNewObjectObjects2= [];
gdjs._49_32begin_32scene_32multiCode.GDNewObject2Objects1= [];
gdjs._49_32begin_32scene_32multiCode.GDNewObject2Objects2= [];

gdjs._49_32begin_32scene_32multiCode.conditionTrue_0 = {val:false};
gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0 = {val:false};
gdjs._49_32begin_32scene_32multiCode.condition1IsTrue_0 = {val:false};


gdjs._49_32begin_32scene_32multiCode.mapOfGDgdjs_46_9549_9532begin_9532scene_9532multiCode_46GDEnterObjects1Objects = Hashtable.newFrom({"Enter": gdjs._49_32begin_32scene_32multiCode.GDEnterObjects1});
gdjs._49_32begin_32scene_32multiCode.eventsList0 = function(runtimeScene) {

{


gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0.val = false;
{
gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1 multi", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs._49_32begin_32scene_32multiCode.GDEnterObjects1);

gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0.val = false;
{
gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49_32begin_32scene_32multiCode.mapOfGDgdjs_46_9549_9532begin_9532scene_9532multiCode_46GDEnterObjects1Objects, runtimeScene, true, false);
}if (gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1 multi", false);
}}

}


{


gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0.val = false;
{
gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs._49_32begin_32scene_32multiCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs._49_32begin_32scene_32multiCode.GDEnterObjects1);
{for(var i = 0, len = gdjs._49_32begin_32scene_32multiCode.GDEnterObjects1.length ;i < len;++i) {
    gdjs._49_32begin_32scene_32multiCode.GDEnterObjects1[i].hide();
}
}}

}


};

gdjs._49_32begin_32scene_32multiCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49_32begin_32scene_32multiCode.GDEnterObjects1.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDEnterObjects2.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDfinObjects1.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDfinObjects2.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDRoBug2Objects1.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDRoBug2Objects2.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDPlayer2Objects1.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDPlayer2Objects2.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDNewObjectObjects1.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDNewObjectObjects2.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDNewObject2Objects1.length = 0;
gdjs._49_32begin_32scene_32multiCode.GDNewObject2Objects2.length = 0;

gdjs._49_32begin_32scene_32multiCode.eventsList0(runtimeScene);

return;

}

gdjs['_49_32begin_32scene_32multiCode'] = gdjs._49_32begin_32scene_32multiCode;
