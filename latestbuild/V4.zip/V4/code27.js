gdjs.ModsCode = {};
gdjs.ModsCode.GDEnterObjects1= [];
gdjs.ModsCode.GDEnterObjects2= [];
gdjs.ModsCode.GDfinObjects1= [];
gdjs.ModsCode.GDfinObjects2= [];
gdjs.ModsCode.GDRoBug2Objects1= [];
gdjs.ModsCode.GDRoBug2Objects2= [];
gdjs.ModsCode.GDPlayer2Objects1= [];
gdjs.ModsCode.GDPlayer2Objects2= [];
gdjs.ModsCode.GDPlayer2HitBoxObjects1= [];
gdjs.ModsCode.GDPlayer2HitBoxObjects2= [];
gdjs.ModsCode.GDNewObjectObjects1= [];
gdjs.ModsCode.GDNewObjectObjects2= [];
gdjs.ModsCode.GDNewObject2Objects1= [];
gdjs.ModsCode.GDNewObject2Objects2= [];
gdjs.ModsCode.GDMooseModsObjects1= [];
gdjs.ModsCode.GDMooseModsObjects2= [];
gdjs.ModsCode.GDMoosePS5Objects1= [];
gdjs.ModsCode.GDMoosePS5Objects2= [];
gdjs.ModsCode.GDFNFBFObjects1= [];
gdjs.ModsCode.GDFNFBFObjects2= [];

gdjs.ModsCode.conditionTrue_0 = {val:false};
gdjs.ModsCode.condition0IsTrue_0 = {val:false};
gdjs.ModsCode.condition1IsTrue_0 = {val:false};
gdjs.ModsCode.condition2IsTrue_0 = {val:false};


gdjs.ModsCode.mapOfGDgdjs_46ModsCode_46GDMoosePS5Objects1Objects = Hashtable.newFrom({"MoosePS5": gdjs.ModsCode.GDMoosePS5Objects1});
gdjs.ModsCode.mapOfGDgdjs_46ModsCode_46GDFNFBFObjects1Objects = Hashtable.newFrom({"FNFBF": gdjs.ModsCode.GDFNFBFObjects1});
gdjs.ModsCode.eventsList0 = function(runtimeScene) {

{


gdjs.ModsCode.condition0IsTrue_0.val = false;
{
gdjs.ModsCode.condition0IsTrue_0.val = !(gdjs.evtsExt__InternetConnectivity__IsDeviceOnline.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}if (gdjs.ModsCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("FNFBF"), gdjs.ModsCode.GDFNFBFObjects1);
gdjs.copyArray(runtimeScene.getObjects("MooseMods"), gdjs.ModsCode.GDMooseModsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MoosePS5"), gdjs.ModsCode.GDMoosePS5Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.ModsCode.GDNewObjectObjects1);
{for(var i = 0, len = gdjs.ModsCode.GDNewObjectObjects1.length ;i < len;++i) {
    gdjs.ModsCode.GDNewObjectObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.ModsCode.GDMooseModsObjects1.length ;i < len;++i) {
    gdjs.ModsCode.GDMooseModsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.ModsCode.GDFNFBFObjects1.length ;i < len;++i) {
    gdjs.ModsCode.GDFNFBFObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.ModsCode.GDMoosePS5Objects1.length ;i < len;++i) {
    gdjs.ModsCode.GDMoosePS5Objects1[i].hide();
}
}}

}


{


gdjs.ModsCode.condition0IsTrue_0.val = false;
{
gdjs.ModsCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.ModsCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.ModsCode.GDNewObjectObjects1);
{for(var i = 0, len = gdjs.ModsCode.GDNewObjectObjects1.length ;i < len;++i) {
    gdjs.ModsCode.GDNewObjectObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MoosePS5"), gdjs.ModsCode.GDMoosePS5Objects1);

gdjs.ModsCode.condition0IsTrue_0.val = false;
gdjs.ModsCode.condition1IsTrue_0.val = false;
{
gdjs.ModsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ModsCode.mapOfGDgdjs_46ModsCode_46GDMoosePS5Objects1Objects, runtimeScene, true, false);
}if ( gdjs.ModsCode.condition0IsTrue_0.val ) {
{
gdjs.ModsCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.ModsCode.condition1IsTrue_0.val) {
{gdjs.evtsExt__URLTools__Redirect.func(runtimeScene, "https://sites.google.com/view/giraffewilleatyougiraffemp3exe/home", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FNFBF"), gdjs.ModsCode.GDFNFBFObjects1);

gdjs.ModsCode.condition0IsTrue_0.val = false;
gdjs.ModsCode.condition1IsTrue_0.val = false;
{
gdjs.ModsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ModsCode.mapOfGDgdjs_46ModsCode_46GDFNFBFObjects1Objects, runtimeScene, true, false);
}if ( gdjs.ModsCode.condition0IsTrue_0.val ) {
{
gdjs.ModsCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.ModsCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1 bf", false);
}}

}


{


gdjs.ModsCode.condition0IsTrue_0.val = false;
{
gdjs.ModsCode.condition0IsTrue_0.val = gdjs.evtsExt__InternetConnectivity__IsDeviceOnline.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.ModsCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("FNFBF"), gdjs.ModsCode.GDFNFBFObjects1);
gdjs.copyArray(runtimeScene.getObjects("MooseMods"), gdjs.ModsCode.GDMooseModsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MoosePS5"), gdjs.ModsCode.GDMoosePS5Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.ModsCode.GDNewObjectObjects1);
{for(var i = 0, len = gdjs.ModsCode.GDNewObjectObjects1.length ;i < len;++i) {
    gdjs.ModsCode.GDNewObjectObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.ModsCode.GDMooseModsObjects1.length ;i < len;++i) {
    gdjs.ModsCode.GDMooseModsObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.ModsCode.GDFNFBFObjects1.length ;i < len;++i) {
    gdjs.ModsCode.GDFNFBFObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.ModsCode.GDMoosePS5Objects1.length ;i < len;++i) {
    gdjs.ModsCode.GDMoosePS5Objects1[i].hide(false);
}
}}

}


};

gdjs.ModsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ModsCode.GDEnterObjects1.length = 0;
gdjs.ModsCode.GDEnterObjects2.length = 0;
gdjs.ModsCode.GDfinObjects1.length = 0;
gdjs.ModsCode.GDfinObjects2.length = 0;
gdjs.ModsCode.GDRoBug2Objects1.length = 0;
gdjs.ModsCode.GDRoBug2Objects2.length = 0;
gdjs.ModsCode.GDPlayer2Objects1.length = 0;
gdjs.ModsCode.GDPlayer2Objects2.length = 0;
gdjs.ModsCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.ModsCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.ModsCode.GDNewObjectObjects1.length = 0;
gdjs.ModsCode.GDNewObjectObjects2.length = 0;
gdjs.ModsCode.GDNewObject2Objects1.length = 0;
gdjs.ModsCode.GDNewObject2Objects2.length = 0;
gdjs.ModsCode.GDMooseModsObjects1.length = 0;
gdjs.ModsCode.GDMooseModsObjects2.length = 0;
gdjs.ModsCode.GDMoosePS5Objects1.length = 0;
gdjs.ModsCode.GDMoosePS5Objects2.length = 0;
gdjs.ModsCode.GDFNFBFObjects1.length = 0;
gdjs.ModsCode.GDFNFBFObjects2.length = 0;

gdjs.ModsCode.eventsList0(runtimeScene);

return;

}

gdjs['ModsCode'] = gdjs.ModsCode;
