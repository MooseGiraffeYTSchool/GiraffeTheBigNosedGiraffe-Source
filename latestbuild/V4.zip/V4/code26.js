gdjs.wCode = {};
gdjs.wCode.GDEnterObjects1= [];
gdjs.wCode.GDEnterObjects2= [];
gdjs.wCode.GDfinObjects1= [];
gdjs.wCode.GDfinObjects2= [];
gdjs.wCode.GDRoBug2Objects1= [];
gdjs.wCode.GDRoBug2Objects2= [];
gdjs.wCode.GDPlayer2Objects1= [];
gdjs.wCode.GDPlayer2Objects2= [];
gdjs.wCode.GDPlayer2HitBoxObjects1= [];
gdjs.wCode.GDPlayer2HitBoxObjects2= [];
gdjs.wCode.GDNewObjectObjects1= [];
gdjs.wCode.GDNewObjectObjects2= [];

gdjs.wCode.conditionTrue_0 = {val:false};
gdjs.wCode.condition0IsTrue_0 = {val:false};
gdjs.wCode.condition1IsTrue_0 = {val:false};


gdjs.wCode.mapOfGDgdjs_46wCode_46GDEnterObjects1Objects = Hashtable.newFrom({"Enter": gdjs.wCode.GDEnterObjects1});
gdjs.wCode.eventsList0 = function(runtimeScene) {

{


gdjs.wCode.condition0IsTrue_0.val = false;
{
gdjs.wCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs.wCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gamemode snif#]", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs.wCode.GDEnterObjects1);

gdjs.wCode.condition0IsTrue_0.val = false;
{
gdjs.wCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.wCode.mapOfGDgdjs_46wCode_46GDEnterObjects1Objects, runtimeScene, true, false);
}if (gdjs.wCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gamemode snif#]", false);
}}

}


{


gdjs.wCode.condition0IsTrue_0.val = false;
{
gdjs.wCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.wCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs.wCode.GDEnterObjects1);
{for(var i = 0, len = gdjs.wCode.GDEnterObjects1.length ;i < len;++i) {
    gdjs.wCode.GDEnterObjects1[i].hide();
}
}}

}


};

gdjs.wCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.wCode.GDEnterObjects1.length = 0;
gdjs.wCode.GDEnterObjects2.length = 0;
gdjs.wCode.GDfinObjects1.length = 0;
gdjs.wCode.GDfinObjects2.length = 0;
gdjs.wCode.GDRoBug2Objects1.length = 0;
gdjs.wCode.GDRoBug2Objects2.length = 0;
gdjs.wCode.GDPlayer2Objects1.length = 0;
gdjs.wCode.GDPlayer2Objects2.length = 0;
gdjs.wCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.wCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.wCode.GDNewObjectObjects1.length = 0;
gdjs.wCode.GDNewObjectObjects2.length = 0;

gdjs.wCode.eventsList0(runtimeScene);

return;

}

gdjs['wCode'] = gdjs.wCode;
