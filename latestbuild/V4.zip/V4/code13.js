gdjs.Giraffe_46exeCode = {};
gdjs.Giraffe_46exeCode.forEachCount0_3 = 0;

gdjs.Giraffe_46exeCode.forEachCount1_3 = 0;

gdjs.Giraffe_46exeCode.forEachIndex3 = 0;

gdjs.Giraffe_46exeCode.forEachObjects3 = [];

gdjs.Giraffe_46exeCode.forEachTotalCount3 = 0;

gdjs.Giraffe_46exeCode.GDEnterObjects1= [];
gdjs.Giraffe_46exeCode.GDEnterObjects2= [];
gdjs.Giraffe_46exeCode.GDEnterObjects3= [];
gdjs.Giraffe_46exeCode.GDfinObjects1= [];
gdjs.Giraffe_46exeCode.GDfinObjects2= [];
gdjs.Giraffe_46exeCode.GDfinObjects3= [];
gdjs.Giraffe_46exeCode.GDRoBug2Objects1= [];
gdjs.Giraffe_46exeCode.GDRoBug2Objects2= [];
gdjs.Giraffe_46exeCode.GDRoBug2Objects3= [];
gdjs.Giraffe_46exeCode.GDPlayer2Objects1= [];
gdjs.Giraffe_46exeCode.GDPlayer2Objects2= [];
gdjs.Giraffe_46exeCode.GDPlayer2Objects3= [];
gdjs.Giraffe_46exeCode.GDPlayer2HitBoxObjects1= [];
gdjs.Giraffe_46exeCode.GDPlayer2HitBoxObjects2= [];
gdjs.Giraffe_46exeCode.GDPlayer2HitBoxObjects3= [];
gdjs.Giraffe_46exeCode.GDPlayerObjects1= [];
gdjs.Giraffe_46exeCode.GDPlayerObjects2= [];
gdjs.Giraffe_46exeCode.GDPlayerObjects3= [];
gdjs.Giraffe_46exeCode.GDPlatformObjects1= [];
gdjs.Giraffe_46exeCode.GDPlatformObjects2= [];
gdjs.Giraffe_46exeCode.GDPlatformObjects3= [];
gdjs.Giraffe_46exeCode.GDJumpthru2Objects1= [];
gdjs.Giraffe_46exeCode.GDJumpthru2Objects2= [];
gdjs.Giraffe_46exeCode.GDJumpthru2Objects3= [];
gdjs.Giraffe_46exeCode.GDJumpthruObjects1= [];
gdjs.Giraffe_46exeCode.GDJumpthruObjects2= [];
gdjs.Giraffe_46exeCode.GDJumpthruObjects3= [];
gdjs.Giraffe_46exeCode.GDTiledGrassPlatformObjects1= [];
gdjs.Giraffe_46exeCode.GDTiledGrassPlatformObjects2= [];
gdjs.Giraffe_46exeCode.GDTiledGrassPlatformObjects3= [];
gdjs.Giraffe_46exeCode.GDTiledCastlePlatformObjects1= [];
gdjs.Giraffe_46exeCode.GDTiledCastlePlatformObjects2= [];
gdjs.Giraffe_46exeCode.GDTiledCastlePlatformObjects3= [];
gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1= [];
gdjs.Giraffe_46exeCode.GDMovingPlatformObjects2= [];
gdjs.Giraffe_46exeCode.GDMovingPlatformObjects3= [];
gdjs.Giraffe_46exeCode.GDGoLeftObjects1= [];
gdjs.Giraffe_46exeCode.GDGoLeftObjects2= [];
gdjs.Giraffe_46exeCode.GDGoLeftObjects3= [];
gdjs.Giraffe_46exeCode.GDGoRightObjects1= [];
gdjs.Giraffe_46exeCode.GDGoRightObjects2= [];
gdjs.Giraffe_46exeCode.GDGoRightObjects3= [];
gdjs.Giraffe_46exeCode.GDLadderObjects1= [];
gdjs.Giraffe_46exeCode.GDLadderObjects2= [];
gdjs.Giraffe_46exeCode.GDLadderObjects3= [];
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1= [];
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2= [];
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects3= [];
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1= [];
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2= [];
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects3= [];
gdjs.Giraffe_46exeCode.GDRoBugObjects1= [];
gdjs.Giraffe_46exeCode.GDRoBugObjects2= [];
gdjs.Giraffe_46exeCode.GDRoBugObjects3= [];
gdjs.Giraffe_46exeCode.GDFlyObjects1= [];
gdjs.Giraffe_46exeCode.GDFlyObjects2= [];
gdjs.Giraffe_46exeCode.GDFlyObjects3= [];
gdjs.Giraffe_46exeCode.GDBackgroundObjectsObjects1= [];
gdjs.Giraffe_46exeCode.GDBackgroundObjectsObjects2= [];
gdjs.Giraffe_46exeCode.GDBackgroundObjectsObjects3= [];
gdjs.Giraffe_46exeCode.GDScoreObjects1= [];
gdjs.Giraffe_46exeCode.GDScoreObjects2= [];
gdjs.Giraffe_46exeCode.GDScoreObjects3= [];
gdjs.Giraffe_46exeCode.GDCoinObjects1= [];
gdjs.Giraffe_46exeCode.GDCoinObjects2= [];
gdjs.Giraffe_46exeCode.GDCoinObjects3= [];
gdjs.Giraffe_46exeCode.GDCoinIconObjects1= [];
gdjs.Giraffe_46exeCode.GDCoinIconObjects2= [];
gdjs.Giraffe_46exeCode.GDCoinIconObjects3= [];
gdjs.Giraffe_46exeCode.GDLeftButtonObjects1= [];
gdjs.Giraffe_46exeCode.GDLeftButtonObjects2= [];
gdjs.Giraffe_46exeCode.GDLeftButtonObjects3= [];
gdjs.Giraffe_46exeCode.GDRightButtonObjects1= [];
gdjs.Giraffe_46exeCode.GDRightButtonObjects2= [];
gdjs.Giraffe_46exeCode.GDRightButtonObjects3= [];
gdjs.Giraffe_46exeCode.GDJumpButtonObjects1= [];
gdjs.Giraffe_46exeCode.GDJumpButtonObjects2= [];
gdjs.Giraffe_46exeCode.GDJumpButtonObjects3= [];
gdjs.Giraffe_46exeCode.GDArrowButtonsBgObjects1= [];
gdjs.Giraffe_46exeCode.GDArrowButtonsBgObjects2= [];
gdjs.Giraffe_46exeCode.GDArrowButtonsBgObjects3= [];
gdjs.Giraffe_46exeCode.GDCheckpointObjects1= [];
gdjs.Giraffe_46exeCode.GDCheckpointObjects2= [];
gdjs.Giraffe_46exeCode.GDCheckpointObjects3= [];
gdjs.Giraffe_46exeCode.GDTopButtonObjects1= [];
gdjs.Giraffe_46exeCode.GDTopButtonObjects2= [];
gdjs.Giraffe_46exeCode.GDTopButtonObjects3= [];
gdjs.Giraffe_46exeCode.GDBottomButtonObjects1= [];
gdjs.Giraffe_46exeCode.GDBottomButtonObjects2= [];
gdjs.Giraffe_46exeCode.GDBottomButtonObjects3= [];
gdjs.Giraffe_46exeCode.GDFadeInObjects1= [];
gdjs.Giraffe_46exeCode.GDFadeInObjects2= [];
gdjs.Giraffe_46exeCode.GDFadeInObjects3= [];
gdjs.Giraffe_46exeCode.GDNewObjectObjects1= [];
gdjs.Giraffe_46exeCode.GDNewObjectObjects2= [];
gdjs.Giraffe_46exeCode.GDNewObjectObjects3= [];
gdjs.Giraffe_46exeCode.GDNewObject2Objects1= [];
gdjs.Giraffe_46exeCode.GDNewObject2Objects2= [];
gdjs.Giraffe_46exeCode.GDNewObject2Objects3= [];
gdjs.Giraffe_46exeCode.GDTime_95LOLObjects1= [];
gdjs.Giraffe_46exeCode.GDTime_95LOLObjects2= [];
gdjs.Giraffe_46exeCode.GDTime_95LOLObjects3= [];
gdjs.Giraffe_46exeCode.GDNewObject3Objects1= [];
gdjs.Giraffe_46exeCode.GDNewObject3Objects2= [];
gdjs.Giraffe_46exeCode.GDNewObject3Objects3= [];

gdjs.Giraffe_46exeCode.conditionTrue_0 = {val:false};
gdjs.Giraffe_46exeCode.condition0IsTrue_0 = {val:false};
gdjs.Giraffe_46exeCode.condition1IsTrue_0 = {val:false};
gdjs.Giraffe_46exeCode.condition2IsTrue_0 = {val:false};
gdjs.Giraffe_46exeCode.conditionTrue_1 = {val:false};
gdjs.Giraffe_46exeCode.condition0IsTrue_1 = {val:false};
gdjs.Giraffe_46exeCode.condition1IsTrue_1 = {val:false};
gdjs.Giraffe_46exeCode.condition2IsTrue_1 = {val:false};


gdjs.Giraffe_46exeCode.eventsList0 = function(runtimeScene) {

{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
{gdjs.Giraffe_46exeCode.conditionTrue_1 = gdjs.Giraffe_46exeCode.condition0IsTrue_0;
gdjs.Giraffe_46exeCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17571892);
}
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}}

}


};gdjs.Giraffe_46exeCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1, gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2);


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( !(gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[k] = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerObjects2[i].setAnimationName("Idle");
}
}}

}


{

/* Reuse gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1 */

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[k] = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerObjects1[i].setAnimationName("Running");
}
}}

}


};gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDGoLeftObjects1Objects = Hashtable.newFrom({"GoLeft": gdjs.Giraffe_46exeCode.GDGoLeftObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDGoRightObjects1Objects = Hashtable.newFrom({"GoRight": gdjs.Giraffe_46exeCode.GDGoRightObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDGoLeftObjects2Objects = Hashtable.newFrom({"GoLeft": gdjs.Giraffe_46exeCode.GDGoLeftObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDSlimeWalkObjects2ObjectsGDgdjs_46Giraffe_9546exeCode_46GDFlyObjects2Objects = Hashtable.newFrom({"SlimeWalk": gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2, "Fly": gdjs.Giraffe_46exeCode.GDFlyObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDGoRightObjects2Objects = Hashtable.newFrom({"GoRight": gdjs.Giraffe_46exeCode.GDGoRightObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDSlimeWalkObjects2ObjectsGDgdjs_46Giraffe_9546exeCode_46GDFlyObjects2Objects = Hashtable.newFrom({"SlimeWalk": gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2, "Fly": gdjs.Giraffe_46exeCode.GDFlyObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46Giraffe_9546exeCode_46GDFlyObjects1Objects = Hashtable.newFrom({"SlimeWalk": gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1, "Fly": gdjs.Giraffe_46exeCode.GDFlyObjects1});
gdjs.Giraffe_46exeCode.eventsList2 = function(runtimeScene) {

};gdjs.Giraffe_46exeCode.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs.Giraffe_46exeCode.GDFlyObjects2 */
/* Reuse gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2 */

gdjs.Giraffe_46exeCode.forEachTotalCount3 = 0;
gdjs.Giraffe_46exeCode.forEachObjects3.length = 0;
gdjs.Giraffe_46exeCode.forEachCount0_3 = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length;
gdjs.Giraffe_46exeCode.forEachTotalCount3 += gdjs.Giraffe_46exeCode.forEachCount0_3;
gdjs.Giraffe_46exeCode.forEachObjects3.push.apply(gdjs.Giraffe_46exeCode.forEachObjects3,gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2);
gdjs.Giraffe_46exeCode.forEachCount1_3 = gdjs.Giraffe_46exeCode.GDFlyObjects2.length;
gdjs.Giraffe_46exeCode.forEachTotalCount3 += gdjs.Giraffe_46exeCode.forEachCount1_3;
gdjs.Giraffe_46exeCode.forEachObjects3.push.apply(gdjs.Giraffe_46exeCode.forEachObjects3,gdjs.Giraffe_46exeCode.GDFlyObjects2);
for(gdjs.Giraffe_46exeCode.forEachIndex3 = 0;gdjs.Giraffe_46exeCode.forEachIndex3 < gdjs.Giraffe_46exeCode.forEachTotalCount3;++gdjs.Giraffe_46exeCode.forEachIndex3) {
gdjs.Giraffe_46exeCode.GDFlyObjects3.length = 0;

gdjs.Giraffe_46exeCode.GDSlimeWalkObjects3.length = 0;


if (gdjs.Giraffe_46exeCode.forEachIndex3 < gdjs.Giraffe_46exeCode.forEachCount0_3) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects3.push(gdjs.Giraffe_46exeCode.forEachObjects3[gdjs.Giraffe_46exeCode.forEachIndex3]);
}
else if (gdjs.Giraffe_46exeCode.forEachIndex3 < gdjs.Giraffe_46exeCode.forEachCount0_3+gdjs.Giraffe_46exeCode.forEachCount1_3) {
    gdjs.Giraffe_46exeCode.GDFlyObjects3.push(gdjs.Giraffe_46exeCode.forEachObjects3[gdjs.Giraffe_46exeCode.forEachIndex3]);
}
if (true) {
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}
}

}


};gdjs.Giraffe_46exeCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1, gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2);


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[k] = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Giraffe_46exeCode.GDFlyObjects1, gdjs.Giraffe_46exeCode.GDFlyObjects2);

/* Reuse gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2 */
gdjs.copyArray(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1, gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2);

{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].setAnimation(1);
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].activateBehavior("PlatformerObject", true);
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects2[i].activateBehavior("PlatformerObject", true);
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").setGravity(1500);
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects2[i].getBehavior("PlatformerObject").setGravity(1500);
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}
{ //Subevents
gdjs.Giraffe_46exeCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1 */

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( !(gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[k] = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


};gdjs.Giraffe_46exeCode.eventsList5 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Giraffe_46exeCode.GDFlyObjects1, gdjs.Giraffe_46exeCode.GDFlyObjects2);

gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs.Giraffe_46exeCode.GDGoLeftObjects2);
gdjs.copyArray(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1, gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2);


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDGoLeftObjects2Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDSlimeWalkObjects2ObjectsGDgdjs_46Giraffe_9546exeCode_46GDFlyObjects2Objects, false, runtimeScene, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Giraffe_46exeCode.GDFlyObjects2 */
/* Reuse gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].returnVariable(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")).setNumber(1);
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects2[i].returnVariable(gdjs.Giraffe_46exeCode.GDFlyObjects2[i].getVariables().get("GoingLeft")).setNumber(1);
}
}}

}


{

gdjs.copyArray(gdjs.Giraffe_46exeCode.GDFlyObjects1, gdjs.Giraffe_46exeCode.GDFlyObjects2);

gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs.Giraffe_46exeCode.GDGoRightObjects2);
gdjs.copyArray(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1, gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2);


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDGoRightObjects2Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDSlimeWalkObjects2ObjectsGDgdjs_46Giraffe_9546exeCode_46GDFlyObjects2Objects, false, runtimeScene, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Giraffe_46exeCode.GDFlyObjects2 */
/* Reuse gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].returnVariable(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")).setNumber(0);
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects2[i].returnVariable(gdjs.Giraffe_46exeCode.GDFlyObjects2[i].getVariables().get("GoingLeft")).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.Giraffe_46exeCode.GDFlyObjects1, gdjs.Giraffe_46exeCode.GDFlyObjects2);

gdjs.copyArray(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1, gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2);


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[k] = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDFlyObjects2[i].getVariableNumber(gdjs.Giraffe_46exeCode.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDFlyObjects2[k] = gdjs.Giraffe_46exeCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDFlyObjects2.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Giraffe_46exeCode.GDFlyObjects2 */
/* Reuse gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(gdjs.Giraffe_46exeCode.GDFlyObjects1, gdjs.Giraffe_46exeCode.GDFlyObjects2);

gdjs.copyArray(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1, gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2);


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[k] = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDFlyObjects2[i].getVariableNumber(gdjs.Giraffe_46exeCode.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDFlyObjects2[k] = gdjs.Giraffe_46exeCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDFlyObjects2.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Giraffe_46exeCode.GDFlyObjects2 */
/* Reuse gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects2[i].flipX(true);
}
}}

}


{



}


{

/* Reuse gdjs.Giraffe_46exeCode.GDFlyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1);
/* Reuse gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1 */

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerHitBoxObjects1Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46Giraffe_9546exeCode_46GDFlyObjects1Objects, false, runtimeScene, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Giraffe_46exeCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.Giraffe_46exeCode.GDCoinObjects1});
gdjs.Giraffe_46exeCode.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Giraffe_46exeCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDScoreObjects1[i].setString("x " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


};gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDLeftButtonObjects2Objects = Hashtable.newFrom({"LeftButton": gdjs.Giraffe_46exeCode.GDLeftButtonObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDRightButtonObjects2Objects = Hashtable.newFrom({"RightButton": gdjs.Giraffe_46exeCode.GDRightButtonObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDTopButtonObjects2Objects = Hashtable.newFrom({"TopButton": gdjs.Giraffe_46exeCode.GDTopButtonObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDBottomButtonObjects2Objects = Hashtable.newFrom({"BottomButton": gdjs.Giraffe_46exeCode.GDBottomButtonObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDJumpButtonObjects1Objects = Hashtable.newFrom({"JumpButton": gdjs.Giraffe_46exeCode.GDJumpButtonObjects1});
gdjs.Giraffe_46exeCode.eventsList7 = function(runtimeScene) {

{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ArrowButtonsBg"), gdjs.Giraffe_46exeCode.GDArrowButtonsBgObjects2);
gdjs.copyArray(runtimeScene.getObjects("BottomButton"), gdjs.Giraffe_46exeCode.GDBottomButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Giraffe_46exeCode.GDJumpButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs.Giraffe_46exeCode.GDLeftButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs.Giraffe_46exeCode.GDRightButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.Giraffe_46exeCode.GDTopButtonObjects2);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDLeftButtonObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDLeftButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDRightButtonObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDRightButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDJumpButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDArrowButtonsBgObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDArrowButtonsBgObjects2[i].hide();
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDTopButtonObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDTopButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDBottomButtonObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDBottomButtonObjects2[i].hide();
}
}}

}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs.Giraffe_46exeCode.GDLeftButtonObjects2);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDLeftButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs.Giraffe_46exeCode.GDRightButtonObjects2);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDRightButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.Giraffe_46exeCode.GDTopButtonObjects2);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDTopButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateUpKey();
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateLadderKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BottomButton"), gdjs.Giraffe_46exeCode.GDBottomButtonObjects2);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDBottomButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateDownKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Giraffe_46exeCode.GDJumpButtonObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDJumpButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerHitBoxObjects2Objects = Hashtable.newFrom({"PlayerHitBox": gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs.Giraffe_46exeCode.GDCheckpointObjects2});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDFadeInObjects2Objects = Hashtable.newFrom({"FadeIn": gdjs.Giraffe_46exeCode.GDFadeInObjects2});
gdjs.Giraffe_46exeCode.eventsList8 = function(runtimeScene) {

{



}


{


{
gdjs.Giraffe_46exeCode.GDFadeInObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDFadeInObjects2Objects, 0, 0, "GUI");
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFadeInObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFadeInObjects2[i].setWidth(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene));
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFadeInObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFadeInObjects2[i].setHeight(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene));
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFadeInObjects2.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFadeInObjects2[i].getBehavior("Tween").addObjectOpacityTween("FadeIn", 0, "easeInQuad", 1500, true);
}
}}

}


};gdjs.Giraffe_46exeCode.eventsList9 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.Giraffe_46exeCode.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
gdjs.Giraffe_46exeCode.condition1IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerHitBoxObjects2Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDCheckpointObjects2Objects, false, runtimeScene, false);
}if ( gdjs.Giraffe_46exeCode.condition0IsTrue_0.val ) {
{
{gdjs.Giraffe_46exeCode.conditionTrue_1 = gdjs.Giraffe_46exeCode.condition1IsTrue_0;
gdjs.Giraffe_46exeCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17591044);
}
}}
if (gdjs.Giraffe_46exeCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Giraffe_46exeCode.GDCheckpointObjects2 */
{runtimeScene.getVariables().getFromIndex(1).setNumber((( gdjs.Giraffe_46exeCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Giraffe_46exeCode.GDCheckpointObjects2[0].getPointX("")));
}{runtimeScene.getVariables().getFromIndex(2).setNumber((( gdjs.Giraffe_46exeCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Giraffe_46exeCode.GDCheckpointObjects2[0].getPointY("")));
}}

}


{



}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 1;
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "life lost sound.wav", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Over act 3", true);
}
{ //Subevents
gdjs.Giraffe_46exeCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i].getY() > 1000 ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[k] = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


{



}


};gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDfinObjects1Objects = Hashtable.newFrom({"fin": gdjs.Giraffe_46exeCode.GDfinObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Giraffe_46exeCode.GDPlayerObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDCoinIconObjects1Objects = Hashtable.newFrom({"CoinIcon": gdjs.Giraffe_46exeCode.GDCoinIconObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Giraffe_46exeCode.GDPlayerObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.Giraffe_46exeCode.GDNewObjectObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDFlyObjects1Objects = Hashtable.newFrom({"Fly": gdjs.Giraffe_46exeCode.GDFlyObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Giraffe_46exeCode.GDPlayerObjects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDJumpthru2Objects1Objects = Hashtable.newFrom({"Jumpthru2": gdjs.Giraffe_46exeCode.GDJumpthru2Objects1});
gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDSlimeWalkObjects1Objects = Hashtable.newFrom({"SlimeWalk": gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1});
gdjs.Giraffe_46exeCode.eventsList10 = function(runtimeScene) {

{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerObjects1[i].setPosition((( gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[0].getPointX("")) - 12,(( gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[0].getPointY("")));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[k] = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}
{ //Subevents
gdjs.Giraffe_46exeCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[k] = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[k] = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Giraffe_46exeCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[k] = gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}}

}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerObjects1[i].flipX(true);
}
}}

}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDPlayerObjects1[i].flipX(false);
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Giraffe_46exeCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Giraffe_46exeCode.GDPlayerObjects1[0].getPointX("")), "", 0);
}}

}


{



}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs.Giraffe_46exeCode.GDGoLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs.Giraffe_46exeCode.GDGoRightObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDGoLeftObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDGoLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDGoRightObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDGoRightObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs.Giraffe_46exeCode.GDGoLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform"), gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDGoLeftObjects1Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1[i].addForce(-(150), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs.Giraffe_46exeCode.GDGoRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform"), gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDGoRightObjects1Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1[i].addForce(150, 0, 1);
}
}}

}


{



}


{



}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Giraffe_46exeCode.GDFlyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SlimeWalk"), gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[i].isCurrentAnimationName("Dead")) ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[k] = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDFlyObjects1.length;i<l;++i) {
    if ( !(gdjs.Giraffe_46exeCode.GDFlyObjects1[i].isCurrentAnimationName("Dead")) ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDFlyObjects1[k] = gdjs.Giraffe_46exeCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDFlyObjects1.length = k;}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Giraffe_46exeCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Giraffe_46exeCode.GDFlyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SlimeWalk"), gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
gdjs.Giraffe_46exeCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[i].isCurrentAnimationName("Dead") ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[k] = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDFlyObjects1[i].isCurrentAnimationName("Dead") ) {
        gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDFlyObjects1[k] = gdjs.Giraffe_46exeCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDFlyObjects1.length = k;}if ( gdjs.Giraffe_46exeCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[i].getBehavior("Tween").isPlaying("FadeOut")) ) {
        gdjs.Giraffe_46exeCode.condition1IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[k] = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDFlyObjects1.length;i<l;++i) {
    if ( !(gdjs.Giraffe_46exeCode.GDFlyObjects1[i].getBehavior("Tween").isPlaying("FadeOut")) ) {
        gdjs.Giraffe_46exeCode.condition1IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDFlyObjects1[k] = gdjs.Giraffe_46exeCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDFlyObjects1.length = k;}}
if (gdjs.Giraffe_46exeCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Giraffe_46exeCode.GDFlyObjects1 */
/* Reuse gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1 */
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeOutQuad", 1500, true);
}
for(var i = 0, len = gdjs.Giraffe_46exeCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDFlyObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeOutQuad", 1500, true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Giraffe_46exeCode.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
gdjs.Giraffe_46exeCode.condition1IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerHitBoxObjects1Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDCoinObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Giraffe_46exeCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Giraffe_46exeCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs.Giraffe_46exeCode.GDCoinObjects1[i].getOpacity() == 255 ) {
        gdjs.Giraffe_46exeCode.condition1IsTrue_0.val = true;
        gdjs.Giraffe_46exeCode.GDCoinObjects1[k] = gdjs.Giraffe_46exeCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs.Giraffe_46exeCode.GDCoinObjects1.length = k;}}
if (gdjs.Giraffe_46exeCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Giraffe_46exeCode.GDCoinObjects1 */
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDCoinObjects1[i].setOpacity(254);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDCoinObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeInQuad", 700, true);
}
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDCoinObjects1[i].getBehavior("Tween").addObjectPositionYTween("MoveUp", (gdjs.Giraffe_46exeCode.GDCoinObjects1[i].getPointY("")) - 50, "easeOutQuad", 700, false);
}
}}

}


{


gdjs.Giraffe_46exeCode.eventsList6(runtimeScene);
}


{


gdjs.Giraffe_46exeCode.eventsList7(runtimeScene);
}


{


gdjs.Giraffe_46exeCode.eventsList9(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("fin"), gdjs.Giraffe_46exeCode.GDfinObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDfinObjects1Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Coming Soon", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CoinIcon"), gdjs.Giraffe_46exeCode.GDCoinIconObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
gdjs.Giraffe_46exeCode.condition1IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDCoinIconObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Giraffe_46exeCode.condition0IsTrue_0.val ) {
{
gdjs.Giraffe_46exeCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Giraffe_46exeCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Pause");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.Giraffe_46exeCode.GDNewObjectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerObjects1Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDNewObjectObjects1Objects, false, runtimeScene, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Coming Soon", false);
}}

}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Time_LOL"), gdjs.Giraffe_46exeCode.GDTime_95LOLObjects1);
{gdjs.evtTools.sound.playMusic(runtimeScene, "26 - Robotnik.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDTime_95LOLObjects1.length ;i < len;++i) {
    gdjs.Giraffe_46exeCode.GDTime_95LOLObjects1[i].returnVariable(gdjs.Giraffe_46exeCode.GDTime_95LOLObjects1[i].getVariables().get("Timer lol")).setString("5:00");
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Time_LOL"), gdjs.Giraffe_46exeCode.GDTime_95LOLObjects1);
{for(var i = 0, len = gdjs.Giraffe_46exeCode.GDTime_95LOLObjects1.length ;i < len;++i) {
    ;
}
}}

}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "s");
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.Giraffe_46exeCode.GDFlyObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDFlyObjects1Objects, -(403), 355, "");
}}

}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 360, "HeliCutscene");
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Coming Soon", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jumpthru2"), gdjs.Giraffe_46exeCode.GDJumpthru2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Giraffe_46exeCode.GDPlayerObjects1);

gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDPlayerObjects1Objects, gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDJumpthru2Objects1Objects, false, runtimeScene, false);
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "AfkaTTACK");
}}

}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "AfkaTTACK");
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Giraffe_46exeCode.mapOfGDgdjs_46Giraffe_9546exeCode_46GDSlimeWalkObjects1Objects, -(802), 330, "");
}}

}


{


gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = false;
{
gdjs.Giraffe_46exeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "s");
}if (gdjs.Giraffe_46exeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "s");
}}

}


{


{
}

}


};

gdjs.Giraffe_46exeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Giraffe_46exeCode.GDEnterObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDEnterObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDEnterObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDfinObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDfinObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDfinObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDRoBug2Objects1.length = 0;
gdjs.Giraffe_46exeCode.GDRoBug2Objects2.length = 0;
gdjs.Giraffe_46exeCode.GDRoBug2Objects3.length = 0;
gdjs.Giraffe_46exeCode.GDPlayer2Objects1.length = 0;
gdjs.Giraffe_46exeCode.GDPlayer2Objects2.length = 0;
gdjs.Giraffe_46exeCode.GDPlayer2Objects3.length = 0;
gdjs.Giraffe_46exeCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDPlayer2HitBoxObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDPlayerObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDPlayerObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDPlayerObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDPlatformObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDPlatformObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDPlatformObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDJumpthru2Objects1.length = 0;
gdjs.Giraffe_46exeCode.GDJumpthru2Objects2.length = 0;
gdjs.Giraffe_46exeCode.GDJumpthru2Objects3.length = 0;
gdjs.Giraffe_46exeCode.GDJumpthruObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDJumpthruObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDJumpthruObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDTiledGrassPlatformObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDTiledGrassPlatformObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDTiledGrassPlatformObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDTiledCastlePlatformObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDTiledCastlePlatformObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDTiledCastlePlatformObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDMovingPlatformObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDMovingPlatformObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDMovingPlatformObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDGoLeftObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDGoLeftObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDGoLeftObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDGoRightObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDGoRightObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDGoRightObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDLadderObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDLadderObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDLadderObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDPlayerHitBoxObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDSlimeWalkObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDRoBugObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDRoBugObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDRoBugObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDFlyObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDFlyObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDFlyObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDBackgroundObjectsObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDBackgroundObjectsObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDBackgroundObjectsObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDScoreObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDScoreObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDScoreObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDCoinObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDCoinObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDCoinObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDCoinIconObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDCoinIconObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDCoinIconObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDLeftButtonObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDLeftButtonObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDLeftButtonObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDRightButtonObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDRightButtonObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDRightButtonObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDJumpButtonObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDJumpButtonObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDJumpButtonObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDArrowButtonsBgObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDArrowButtonsBgObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDArrowButtonsBgObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDCheckpointObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDCheckpointObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDCheckpointObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDTopButtonObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDTopButtonObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDTopButtonObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDBottomButtonObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDBottomButtonObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDBottomButtonObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDFadeInObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDFadeInObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDFadeInObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDNewObjectObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDNewObjectObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDNewObjectObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDNewObject2Objects1.length = 0;
gdjs.Giraffe_46exeCode.GDNewObject2Objects2.length = 0;
gdjs.Giraffe_46exeCode.GDNewObject2Objects3.length = 0;
gdjs.Giraffe_46exeCode.GDTime_95LOLObjects1.length = 0;
gdjs.Giraffe_46exeCode.GDTime_95LOLObjects2.length = 0;
gdjs.Giraffe_46exeCode.GDTime_95LOLObjects3.length = 0;
gdjs.Giraffe_46exeCode.GDNewObject3Objects1.length = 0;
gdjs.Giraffe_46exeCode.GDNewObject3Objects2.length = 0;
gdjs.Giraffe_46exeCode.GDNewObject3Objects3.length = 0;

gdjs.Giraffe_46exeCode.eventsList10(runtimeScene);

return;

}

gdjs['Giraffe_46exeCode'] = gdjs.Giraffe_46exeCode;
