gdjs.Game_32Over_32act_323Code = {};
gdjs.Game_32Over_32act_323Code.GDEnterObjects1= [];
gdjs.Game_32Over_32act_323Code.GDEnterObjects2= [];
gdjs.Game_32Over_32act_323Code.GDfinObjects1= [];
gdjs.Game_32Over_32act_323Code.GDfinObjects2= [];
gdjs.Game_32Over_32act_323Code.GDRoBug2Objects1= [];
gdjs.Game_32Over_32act_323Code.GDRoBug2Objects2= [];
gdjs.Game_32Over_32act_323Code.GDPlayer2Objects1= [];
gdjs.Game_32Over_32act_323Code.GDPlayer2Objects2= [];
gdjs.Game_32Over_32act_323Code.GDPlayer2HitBoxObjects1= [];
gdjs.Game_32Over_32act_323Code.GDPlayer2HitBoxObjects2= [];
gdjs.Game_32Over_32act_323Code.GDNewObjectObjects1= [];
gdjs.Game_32Over_32act_323Code.GDNewObjectObjects2= [];
gdjs.Game_32Over_32act_323Code.GDNewObject2Objects1= [];
gdjs.Game_32Over_32act_323Code.GDNewObject2Objects2= [];
gdjs.Game_32Over_32act_323Code.GDNewObject3Objects1= [];
gdjs.Game_32Over_32act_323Code.GDNewObject3Objects2= [];
gdjs.Game_32Over_32act_323Code.GDNewObject4Objects1= [];
gdjs.Game_32Over_32act_323Code.GDNewObject4Objects2= [];
gdjs.Game_32Over_32act_323Code.GDNewObject5Objects1= [];
gdjs.Game_32Over_32act_323Code.GDNewObject5Objects2= [];
gdjs.Game_32Over_32act_323Code.GDNewObject6Objects1= [];
gdjs.Game_32Over_32act_323Code.GDNewObject6Objects2= [];

gdjs.Game_32Over_32act_323Code.conditionTrue_0 = {val:false};
gdjs.Game_32Over_32act_323Code.condition0IsTrue_0 = {val:false};
gdjs.Game_32Over_32act_323Code.condition1IsTrue_0 = {val:false};


gdjs.Game_32Over_32act_323Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


gdjs.Game_32Over_32act_323Code.condition0IsTrue_0.val = false;
{
gdjs.Game_32Over_32act_323Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Game_32Over_32act_323Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "gameOver.ogg", 1, true, 100, 0.5);
}}

}


{


gdjs.Game_32Over_32act_323Code.condition0IsTrue_0.val = false;
{
gdjs.Game_32Over_32act_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Return");
}if (gdjs.Game_32Over_32act_323Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "gameOverEnd.ogg", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1-3 part 2", false);
}{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}}

}


};

gdjs.Game_32Over_32act_323Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32Over_32act_323Code.GDEnterObjects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDEnterObjects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDfinObjects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDfinObjects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDRoBug2Objects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDRoBug2Objects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDPlayer2Objects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDPlayer2Objects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDPlayer2HitBoxObjects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDPlayer2HitBoxObjects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObjectObjects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObjectObjects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject2Objects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject2Objects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject3Objects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject3Objects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject4Objects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject4Objects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject5Objects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject5Objects2.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject6Objects1.length = 0;
gdjs.Game_32Over_32act_323Code.GDNewObject6Objects2.length = 0;

gdjs.Game_32Over_32act_323Code.eventsList0(runtimeScene);

return;

}

gdjs['Game_32Over_32act_323Code'] = gdjs.Game_32Over_32act_323Code;
