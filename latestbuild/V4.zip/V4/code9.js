gdjs.Game_32OverCode = {};
gdjs.Game_32OverCode.GDEnterObjects1= [];
gdjs.Game_32OverCode.GDEnterObjects2= [];
gdjs.Game_32OverCode.GDfinObjects1= [];
gdjs.Game_32OverCode.GDfinObjects2= [];
gdjs.Game_32OverCode.GDRoBug2Objects1= [];
gdjs.Game_32OverCode.GDRoBug2Objects2= [];
gdjs.Game_32OverCode.GDPlayer2Objects1= [];
gdjs.Game_32OverCode.GDPlayer2Objects2= [];
gdjs.Game_32OverCode.GDPlayer2HitBoxObjects1= [];
gdjs.Game_32OverCode.GDPlayer2HitBoxObjects2= [];
gdjs.Game_32OverCode.GDNewObjectObjects1= [];
gdjs.Game_32OverCode.GDNewObjectObjects2= [];
gdjs.Game_32OverCode.GDNewObject2Objects1= [];
gdjs.Game_32OverCode.GDNewObject2Objects2= [];
gdjs.Game_32OverCode.GDNewObject3Objects1= [];
gdjs.Game_32OverCode.GDNewObject3Objects2= [];
gdjs.Game_32OverCode.GDNewObject4Objects1= [];
gdjs.Game_32OverCode.GDNewObject4Objects2= [];

gdjs.Game_32OverCode.conditionTrue_0 = {val:false};
gdjs.Game_32OverCode.condition0IsTrue_0 = {val:false};
gdjs.Game_32OverCode.condition1IsTrue_0 = {val:false};


gdjs.Game_32OverCode.mapOfGDgdjs_46Game_9532OverCode_46GDEnterObjects1Objects = Hashtable.newFrom({"Enter": gdjs.Game_32OverCode.GDEnterObjects1});
gdjs.Game_32OverCode.eventsList0 = function(runtimeScene) {

{


{
}

}


{


gdjs.Game_32OverCode.condition0IsTrue_0.val = false;
{
gdjs.Game_32OverCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Game_32OverCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "gameOver.ogg", 1, true, 100, 1);
}}

}


{


gdjs.Game_32OverCode.condition0IsTrue_0.val = false;
{
gdjs.Game_32OverCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Return");
}if (gdjs.Game_32OverCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "gameOverEnd.ogg", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1", false);
}{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs.Game_32OverCode.GDEnterObjects1);

gdjs.Game_32OverCode.condition0IsTrue_0.val = false;
{
gdjs.Game_32OverCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Game_32OverCode.mapOfGDgdjs_46Game_9532OverCode_46GDEnterObjects1Objects, runtimeScene, true, false);
}if (gdjs.Game_32OverCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "gameOverEnd.ogg", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1", false);
}{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}}

}


{


gdjs.Game_32OverCode.condition0IsTrue_0.val = false;
{
gdjs.Game_32OverCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.Game_32OverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enter"), gdjs.Game_32OverCode.GDEnterObjects1);
{for(var i = 0, len = gdjs.Game_32OverCode.GDEnterObjects1.length ;i < len;++i) {
    gdjs.Game_32OverCode.GDEnterObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};

gdjs.Game_32OverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32OverCode.GDEnterObjects1.length = 0;
gdjs.Game_32OverCode.GDEnterObjects2.length = 0;
gdjs.Game_32OverCode.GDfinObjects1.length = 0;
gdjs.Game_32OverCode.GDfinObjects2.length = 0;
gdjs.Game_32OverCode.GDRoBug2Objects1.length = 0;
gdjs.Game_32OverCode.GDRoBug2Objects2.length = 0;
gdjs.Game_32OverCode.GDPlayer2Objects1.length = 0;
gdjs.Game_32OverCode.GDPlayer2Objects2.length = 0;
gdjs.Game_32OverCode.GDPlayer2HitBoxObjects1.length = 0;
gdjs.Game_32OverCode.GDPlayer2HitBoxObjects2.length = 0;
gdjs.Game_32OverCode.GDNewObjectObjects1.length = 0;
gdjs.Game_32OverCode.GDNewObjectObjects2.length = 0;
gdjs.Game_32OverCode.GDNewObject2Objects1.length = 0;
gdjs.Game_32OverCode.GDNewObject2Objects2.length = 0;
gdjs.Game_32OverCode.GDNewObject3Objects1.length = 0;
gdjs.Game_32OverCode.GDNewObject3Objects2.length = 0;
gdjs.Game_32OverCode.GDNewObject4Objects1.length = 0;
gdjs.Game_32OverCode.GDNewObject4Objects2.length = 0;

gdjs.Game_32OverCode.eventsList0(runtimeScene);

return;

}

gdjs['Game_32OverCode'] = gdjs.Game_32OverCode;
